# SHARLAN — Premium Winter Streetwear
### Current status: Launch-Safe Temporary Storefront, ready to deploy

This started as a Phase 1–3 ecommerce prototype (full shop, cart, checkout, accounts) built with vanilla HTML/CSS/JS. **As of the most recent update, it has been converted into a launch-safe temporary storefront** while the real backend (Medusa.js + PostgreSQL) is built separately — see "Launch-Safety Update" near the end of this file for what that means and why.

**If you're picking this project up, read that section first** — it explains what's real, what's demo data, and what to do before this goes fully public.

## Project structure

```
sharlan/
├── index.html                 → Homepage
├── README.md                  → This file
├── robots.txt                 → Crawler rules (only indexes real pages)
├── sitemap.xml                → Only lists Home + Shop until real products exist
├── assets/
│   ├── css/
│   │   ├── style.css          → Design tokens, layout, all components/sections
│   │   └── responsive.css     → Tablet/mobile breakpoints (992px, 768px, 600px, 380px)
│   ├── js/
│   │   ├── navigation.js      → Sticky nav, hamburger menu, mobile panel, search overlay
│   │   ├── ui.js               → Toast notifications, scroll-reveal, back-to-top, tab filter
│   │   └── app.js              → Cart drawer state (add/remove/qty), PKR formatting
│   ├── images/                 → Empty folders, organized by category — see "Images" below
│   │   ├── hero/
│   │   ├── jackets/
│   │   ├── sneakers/
│   │   ├── jeans/
│   │   ├── watches/
│   │   ├── lifestyle/men/
│   │   ├── lifestyle/women/
│   │   ├── banners/
│   │   └── instagram/
│   └── icons/                  → Reserved for logo/favicon files
└── pages/                      → Reserved for Phase 2 (Shop, Product, Cart, Checkout, etc.)
```

## Images — important

You don't have product photos yet, so the homepage currently **hotlinks directly to Unsplash** (e.g. `https://images.unsplash.com/photo-xxxx?...`) for every hero, category, product, and testimonial image. This works immediately in any browser with an internet connection — no setup needed.

The `/assets/images/` folders above are already organized and ready for your real photos. When you have them:
1. Drop each photo into the matching folder (e.g. a new jacket photo → `/assets/images/jackets/`).
2. In `index.html`, replace the matching Unsplash URL with your local path, e.g. `src="assets/images/jackets/arctic-puffer-01.jpg"`.

Every `<img>` already has descriptive `alt` text and `width`/`height` attributes — keep those when you swap the `src`.

## What changed vs. your original file

- **Split into real files** — CSS and JS are no longer inline; separated into `style.css` / `responsive.css` / three JS modules.
- **Fixed the mobile nav bug** — the original hid `.nav-links` under 600px with no way to reopen it. There's now a working hamburger → slide-out panel with focus handling and Escape-to-close.
- **Added a real cart drawer** — quantity controls, remove, subtotal in PKR, persisted to `localStorage` so it survives a refresh. Checkout button is present but intentionally disabled (arrives in Phase 3).
- **Replaced the `alert()` newsletter popup** with inline validation and a toast notification system (`SharlanToast`), reusable anywhere in the site.
- **Added the sections your brief called for that weren't built yet**: announcement bar, winter collection banner, featured watches showcase, Instagram gallery, Pakistan trust strip (COD / JazzCash / EasyPaisa / WhatsApp), floating WhatsApp button, back-to-top button.
- **Currency switched to PKR** throughout (`Rs. 18,900` style formatting via `formatPKR()` in `app.js`).
- **SEO**: meta description, canonical URL, Open Graph + Twitter Card tags, `ClothingStore` structured data (JSON-LD), semantic heading hierarchy (single `h1` in hero, `h2`s per section).
- **Accessibility**: skip-to-content link, `aria-label`s on every icon-only button, visible focus states, `prefers-reduced-motion` respected, alt text on every image, keyboard-operable nav/cart/search (Escape closes all three).
- **Performance**: `loading="lazy"` on every below-the-fold image, explicit `width`/`height` to prevent layout shift, `rel="preconnect"` for fonts and image CDN, CSS/JS split into cacheable files instead of one inline blob.
- **Design system**: full token set in `:root` — type scale, 4px-based spacing scale, shadow scale, motion tokens — plus the two new support colors from your brief (olive, brown) reserved for future seasonal accents. Montserrat (display) + Poppins (body) per your typography request.
- **Signature interaction**: an icy diagonal "glint" sweep on button hover, and a short frost-line accent under every section heading — small, consistent motifs tying back to the winter theme without being generic.

## Self-review pass (bug fixes & polish, before Phase 2)

After Phase 1 was approved, I re-audited every file. Fixes applied:

- **Real bug — tab filter mismatch on load**: the "New Arrivals" tab displayed as active on page load, but the product grid actually showed all 6 products (new + best sellers) until you clicked a tab. Now the grid filters correctly on first render.
- **Broken/dead links**: every placeholder link (policy pages, social icons, category "Shop X" links, Instagram tiles, "Quick View") used to silently jump to the top of the page with no feedback when clicked. They now show a clear "not live yet" toast instead of behaving like a broken link.
- **Search input**: pressing Enter in the search box did nothing detectable. It now shows a toast explaining search arrives with the Phase 2 catalog, so it doesn't feel broken.
- **Accessibility — contrast**: the muted grey text color (`--color-grey`) measured 4.27:1 against white, just under the WCAG AA 4.5:1 minimum for body text. Darkened to `#6c6c6f` (4.97:1) — passes AA with margin.
- **Accessibility — focus management**: mobile menu, search overlay, and cart drawer are now proper `role="dialog"` regions with focus trapped inside while open (Tab/Shift+Tab no longer escapes to the page behind them), and focus returns to the triggering button on close. Mobile menu previously focused its own close button first instead of the first nav link — fixed.
- **Missing visual state**: the "Add to Cart" success state (`is-added`) was set by JS but had no matching CSS, so the button color never actually changed. Added the style.
- **Consistency**: WhatsApp links now all open in a new tab (`target="_blank" rel="noopener"`) — one of the three previously didn't match the others.
- **Performance**: removed the guaranteed 404 request for a missing `/favicon.ico` by adding a real SVG favicon (`assets/icons/favicon.svg`); bumped the Font Awesome CDN link to the current LTS release (6.7.2, previously pinned to an older 6.5.1 build).
- **Mobile viewport polish**: verified all breakpoints (992 / 768 / 600 / 380px) render without overflow or overlap; no changes needed beyond the fixes above.

## Phase 2 — Shop & Products (complete)

Adds the full shopping layer on top of the Phase 1 homepage.

### New files
```
sharlan/
├── pages/
│   ├── shop.html        → Shop All / category / gender / collection listing (one page, URL-driven)
│   ├── product.html     → Product detail page (reads ?id=)
│   └── wishlist.html    → Saved items page
└── assets/
    ├── css/
    │   ├── shop.css      → Filters, toolbar, grid/list view, pagination, quick view modal
    │   └── product.css   → Gallery, tabs, related/FBT/recently-viewed sections
    └── js/
        ├── products.js         → Single source of truth for all 13 products
        ├── shop.js             → Search, filter, sort, pagination, grid/list, quick view, wishlist
        ├── product-detail.js   → Gallery/zoom, options, tabs, related, FBT, recently viewed
        └── wishlist.js         → Renders/removes saved items
```

### Design decision: one Shop page, not nine
The brief lists Shop, Men, Women, Jackets, Sneakers, Jeans, Watches, Winter Collection, New Arrivals, and Best Sellers as separate pages. Rather than duplicating the same grid/filter/sort logic into nine near-identical HTML files, `shop.html` reads its context from URL parameters and filters `products.js` accordingly:

- `shop.html` → Shop All
- `shop.html?category=jackets` → Jackets (same pattern for sneakers/jeans/watches)
- `shop.html?gender=women` → Women
- `shop.html?collection=winter` → Winter Collection
- `shop.html?collection=new` → New Arrivals
- `shop.html?collection=best` → Best Sellers

This is the same pattern real ecommerce platforms use, and it directly serves the brief's own requirement to "prepare the website so additional categories can easily be added later" — a new category is a few lines in `products.js`, not a new HTML file.

### Product catalog
Expanded from the original 6 homepage products to **13 products across all 4 categories** (4 jackets, 3 sneakers, 3 jeans, 3 watches; 8 men's/unisex, 4 women's items) so every filter path has real results to show. Each product has full data: sizes, colors, material, stock status, rating, and description — ready for the product detail page.

### Shop features delivered
Search (debounced), category/color/size/price filters with active-filter chips, sort (Newest / Best Selling / Price ↑↓), pagination, grid/list view toggle, quick view modal, wishlist toggle — all per the brief's Shop Features list.

### Product page features delivered
Gallery with thumbnail switching and click-to-zoom, description, specs table, available sizes/colors, stock status, delivery & returns info (tab), customer reviews (tab + summary), related products, frequently bought together (with bundle total + add-all), recently viewed (localStorage-backed).

### Wishlist
Fully wired to a shared `localStorage` key (`sharlan_wishlist_v1`) — saving a wishlist item on the homepage, Shop grid, or product page all show up on `wishlist.html`, with remove and add-to-cart actions.

### Homepage updates
- "Shop" nav item now points to the real Shop page; category cards and product cards link into `shop.html?category=X` and `product.html?id=X` respectively
- Footer Shop links point to their respective filtered views
- Homepage wishlist buttons now persist to the same shared key instead of just toggling a visual state
- Fixed an accessibility bug introduced while wiring these links: the product image link and the quick-action buttons (wishlist/quick view) were briefly nested (invalid — a link can't contain other interactive controls); corrected to sibling elements, matching the pattern used on the Shop page

### Known placeholders (by design — arrive in later phases)
- Checkout button is present but disabled everywhere (Phase 3)
- Cart/wishlist data is stored in `localStorage`, not a backend — fine for this stage, will need a real account system in Phase 3
- Category/size/brand filter checkboxes support one active category at a time for simplicity; multi-category filtering can be added if you'd like it before Phase 3

## Phase 3 — Cart, Checkout, Authentication, Account, Track Order (complete)

### Self-review pass (before Phase 3 work began)
Reviewed every file from Phases 1–2 against the requested checklist. Found and fixed:
- **Broken/dead search**: the global nav search box showed "not available yet" on Enter — stale copy left over from before the Shop page existed. Now redirects to `shop.html?q=<query>`, which `shop.js` already knows how to filter on.
- **Missing dialog accessibility**: the Shop page's Quick View modal and mobile filter drawer had no `role="dialog"`, no focus trap, and didn't return focus to the trigger element on close — inconsistent with the pattern already used for the mobile nav/search/cart drawer. Fixed to match.
- **Stale ARIA state**: wishlist heart buttons always said `aria-label="Toggle wishlist"` regardless of state. Now say "Add to wishlist" / "Remove from wishlist" and update live.
- **Missing SEO on Shop/Product pages**: `shop.html` and `product.html` had no canonical URL, Open Graph, or Twitter Card tags at all (index.html had them, these didn't). Added, and made them dynamic — canonical/OG update per category filter on Shop, and per product (including product image) on the Product page.
- Confirmed clean: no broken links, no JS syntax errors, no duplicate CSS rules, no duplicate IDs, no console.log debug leftovers.

### New pages
```
pages/
├── cart.html            → Full cart page (line items, coupon, shipping estimator, summary)
├── checkout.html        → 4-step checkout (Billing → Delivery → Payment → Review → Confirmation)
├── login.html
├── register.html
├── forgot-password.html
├── account.html         → Dashboard: Orders, Wishlist, Addresses, Details, Password
└── track-order.html     → Order lookup + status timeline
```

### New shared data layers (`assets/js/`)
- `orders-store.js` — localStorage-backed order records, read by checkout, account, and track-order
- `auth-store.js` — localStorage-backed demo accounts/sessions
- `addresses-store.js` — saved delivery addresses, shared between checkout and account

**Important caveat, stated plainly:** these are demo data layers, not a real backend. `auth-store.js` stores passwords in plain text in the browser's `localStorage` purely to simulate the login/register UX — this is explicitly called out in the file's own header comment and must be replaced with a real authenticated backend (hashed passwords, server-side sessions, an actual database) before this site handles real customers or real payment data. This matches the brief's own instruction not to integrate a payment gateway yet — the same logic extends to auth.

### Architectural decisions
- **Cart API extended, not duplicated.** `app.js` already owned the cart (from Phase 1). Rather than having `cart-page.js` read/write `localStorage` directly, I extended `window.SharlanCart` with proper `removeAt`, `decreaseAt`, `increaseAt`, and `clear` methods. Every page that touches the cart goes through this one API — one source of truth, no drift between the drawer and the full cart page.
- **Checkout combines Billing + Shipping into one step.** The brief lists them separately, but for a Pakistan-focused COD-heavy store, shipping to anywhere other than the billing contact is the exception rather than the rule. Combining them cuts a step out of the funnel (a real conversion consideration for the brief's CRO goal) without losing any of the requested fields. A "ship to a different address" toggle can be added later without restructuring the step.
- **Guest checkout works fully; login is optional.** Checkout never requires an account — it only pre-fills billing/address fields if someone happens to be signed in. This matches how most Pakistani ecommerce COD checkouts work in practice.
- **Demo data is seeded, not empty.** Track Order and Account > My Orders would be empty and hard to evaluate on a fresh browser, so `orders-store.js` seeds two realistic demo orders (and `auth-store.js` seeds one demo login) the first time each is used — but only if nothing exists yet, so it never overwrites real usage.
- **Minimal header on Checkout/Login/Register/Forgot Password.** These pages intentionally drop the mega-nav, search, and floating WhatsApp button — standard ecommerce practice to reduce distraction during a sensitive flow (entering payment/personal info). Every shared script (`navigation.js`, `ui.js`, `app.js`) is null-guarded, so loading them on a page with a stripped-down header doesn't error; they simply no-op for the elements that aren't present.

### Assumptions made
- Coupon codes (`WINTER10`, `FREESHIP`) are hardcoded placeholders, not a real discount engine — matches the brief's "coupon code support (placeholder)" wording.
- Shipping cost is a simple flat/city-tier placeholder (Rs. 250 standard / Rs. 500 express, free over Rs. 5,000), not a real rate calculator.
- One address book per browser (not per-account) in this demo, since there's no real backend tying addresses to a specific authenticated user yet.
- Order status ("processing" → "shipped" → "delivered") is static demo data — there's no courier integration to update it automatically.

### Remaining improvements before Phase 4
- Replace `auth-store.js` with real backend authentication before launch — this is the single most important item, flagged above and worth repeating.
- Multi-category filter support on the Shop page (currently one active category at a time) if you want it before further phases.
- A "ship to a different address" toggle on checkout, if useful.
- Real payment gateway integration (explicitly out of scope for Phase 3 per your instructions).

## Known placeholders (by design, for now)

- Nav links, footer links, and category/product "view" links point to `#` — real routes arrive once Shop/Product pages exist in Phase 2.
- Checkout button in the cart drawer is present but disabled.
- WhatsApp links use a placeholder number (`923000000000`) — swap for your real business number.
- Search input doesn't return results yet — that's a Phase 2 feature once there's a product catalog to search.

## Recommendations before Phase 2

1. **Confirm your real WhatsApp business number and city-level delivery estimates** — currently placeholders in the footer/nav/strip.
2. **Decide on your actual size range and fit categories** now — it'll shape the Shop filter structure in Phase 2.
3. If you have even a few real product photos, send them before Phase 2 — building the product grid and detail page against real assets (vs. more Unsplash placeholders) will save a rework pass later.

---

## ⚠️ Launch-Safety Update (supersedes earlier phase notes above)

Everything above this point describes the original Phase 1–3 prototype, which simulated a full ecommerce backend (accounts, checkout, order tracking) entirely in the browser's `localStorage`. **That simulation has since been disabled** because SHARLAN began receiving real customer interest before the real Medusa backend was ready. Read this section as the current source of truth — some notes above (e.g. "Checkout button is disabled," "WhatsApp number is a placeholder") are now out of date.

### What changed
- **Real contact info is now live everywhere:** `hello@sharlan.store`, `+92 316 210 9008` (WhatsApp), Islamabad, Pakistan, Mon–Sat 10 AM–8 PM PKT.
- **Checkout, Login, Register, Forgot Password, Account, and Track Order are disabled.** Each shows an honest "not live yet" notice with a WhatsApp/email button — they no longer pretend to process anything. Their JavaScript files (`checkout.js`, `auth.js`, `auth-store.js`, `account.js`, `track-order.js`, `orders-store.js`, `addresses-store.js`) are preserved in the codebase, unused, for the future Medusa integration.
- **The Cart page now ends in "Send Order Request via WhatsApp"** instead of a fake checkout. It builds a real message from the actual cart contents (product, size, quantity, price, subtotal) and opens it in WhatsApp — a human on the SHARLAN team confirms the order manually. No order number is generated, nothing is saved anywhere.
- **Fabricated content removed:** demo star ratings, "Verified Buyer" reviews, homepage testimonials, hardcoded stock badges ("In Stock"/"Low Stock"), fake coupon codes (`WINTER10`/`FREESHIP`), and unverified policy claims (specific delivery-day promises, "7-day exchange," "100% authentic," JazzCash/EasyPaisa as if already integrated).
- **Navigation and footer cleaned up:** links that used to point to the disabled Login/Register/Account/Track Order pages now point to WhatsApp or were removed, so there are no dead-end paths in the primary nav.
- **`robots.txt` and `sitemap.xml` added** at the project root — only Home and Shop are marked indexable; every disabled/utility page is excluded; the sitemap deliberately excludes individual product URLs until real products exist (indexing demo products would put fake items in search results).

### What's still demo data
**The 13 products in `assets/js/products.js` are still placeholder data** — Unsplash stock photos, invented prices, invented descriptions. This is the one remaining thing before a real public launch: replace this file's contents with real SHARLAN products before announcing the site publicly, using the field template below.

**Product data template** (add one of these per real product):
```
Product Name:
Category:            (Jackets / Sneakers / Jeans / Watches / etc.)
Price (PKR):
Available Sizes:
Available Colors:
Material / Fabric:
Short Description:
Full Description:
Product Photos:       (multiple real angles — required)
Stock Quantity:        (optional — leave blank rather than guess)
Care Instructions:     (if applicable)
SKU / Product Code:    (optional, recommended for consistency)
```

### Deployment — how to actually put this online

This is a **fully static site** — plain HTML/CSS/JS, no build step, no Node.js required to run it. The simplest deployment path, consistent with the approved long-term architecture (which already uses Cloudflare for DNS/CDN):

1. **Push this project to a GitHub repository** (if it isn't already in one).
2. **Go to the Cloudflare dashboard → Workers & Pages → Create → Pages → Connect to Git**, and select the repository.
3. **Build settings:** leave the build command empty and set the output directory to `/` (project root) — there's nothing to build, it's already static HTML.
4. **Deploy.** Cloudflare will give you a `*.pages.dev` URL immediately — this is safe to open and click through before pointing your real domain at it.
5. **Connect your domain:** in the same Pages project, go to Custom Domains and add `sharlan.store` (and `www.sharlan.store`). If your domain's DNS is already on Cloudflare, this is a couple of clicks; if not, Cloudflare will walk you through updating your nameservers.
6. **SSL is automatic** — Cloudflare issues and renews the certificate for you, no separate action needed.

### Before making it public
Do a manual click-through first — homepage → shop → product → add to cart → cart → "Send Order Request via WhatsApp" — and confirm the WhatsApp message looks right on your own phone. Then decide:
- **Soft launch now** with the demo catalog clearly understood by you (not customers) to be placeholder, purely to test that the deployment pipeline and WhatsApp order flow work end-to-end, or
- **Wait to announce publicly** until the product data template above is filled in with real SHARLAN products and photos.

Either way, the underlying site is technically ready to deploy — the product catalog is the only remaining gap between "deployed" and "actually representing SHARLAN's real inventory."
