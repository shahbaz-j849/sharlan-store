/* ==========================================================================
   SHARLAN — CHECKOUT.JS
   Drives the multi-step checkout: Billing -> Shipping -> Delivery Method ->
   Payment -> Review -> Confirmation. No payment gateway integration yet
   (per Phase 3 scope) — placing an order simulates success, writes to the
   shared orders-store, and shows a confirmation screen with an order number.
   ========================================================================== */

(function () {
  'use strict';

  if (window.SharlanOrders && window.SharlanOrders.seedDemoIfEmpty) {
    window.SharlanOrders.seedDemoIfEmpty();
  }

  function formatPKR(amount) {
    return 'Rs. ' + Number(amount).toLocaleString('en-PK');
  }

  const CITY_ESTIMATES = {
    Karachi: { days: '2-3', cost: 250 },
    Lahore: { days: '2-3', cost: 250 },
    Islamabad: { days: '2-3', cost: 250 },
    Rawalpindi: { days: '2-3', cost: 250 },
    Faisalabad: { days: '3-5', cost: 300 },
    Peshawar: { days: '3-5', cost: 300 },
    Multan: { days: '3-5', cost: 300 },
    Quetta: { days: '4-6', cost: 400 }
  };
  const FREE_SHIPPING_THRESHOLD = 5000;

  const STEPS = ['billing', 'delivery', 'payment', 'review'];
  let currentStepIndex = 0;

  const items = window.SharlanCart ? window.SharlanCart.getItems() : [];

  // No items — send back to the cart rather than showing a broken checkout.
  if (!items.length) {
    window.location.href = 'cart.html';
    return;
  }

  let appliedCoupon = null;
  try {
    const stored = sessionStorage.getItem('sharlan_applied_coupon');
    if (stored) appliedCoupon = JSON.parse(stored);
  } catch (e) {
    appliedCoupon = null;
  }

  const state = {
    billing: { firstName: '', lastName: '', email: '', phone: '' },
    shipping: { address: '', city: '', postalCode: '' },
    delivery: 'standard',
    payment: 'cod',
    notes: ''
  };

  /* --------------------------------------------------------------------
     STEP NAVIGATION
     -------------------------------------------------------------------- */
  function goToStep(index) {
    currentStepIndex = Math.max(0, Math.min(index, STEPS.length - 1));
    STEPS.forEach((step, i) => {
      const panel = document.getElementById('step-' + step);
      if (panel) panel.classList.toggle('active', i === currentStepIndex);
    });

    document.querySelectorAll('.stepper-step').forEach((el, i) => {
      el.classList.toggle('is-active', i === currentStepIndex);
      el.classList.toggle('is-complete', i < currentStepIndex);
    });

    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  function validateStep(stepName) {
    let valid = true;

    if (stepName === 'billing') {
      const fields = [
        ['billing-firstName', state.billing, 'firstName'],
        ['billing-lastName', state.billing, 'lastName'],
        ['billing-email', state.billing, 'email'],
        ['billing-phone', state.billing, 'phone']
      ];
      fields.forEach(([id, obj, key]) => {
        const input = document.getElementById(id);
        const group = input.closest('.form-group');
        const ok = input.checkValidity() && input.value.trim();
        group.classList.toggle('has-error', !ok);
        if (ok) obj[key] = input.value.trim();
        valid = valid && ok;
      });

      const addr = document.getElementById('shipping-address');
      const city = document.getElementById('shipping-city');
      const postal = document.getElementById('shipping-postal');
      [
        [addr, state.shipping, 'address'],
        [city, state.shipping, 'city'],
        [postal, state.shipping, 'postalCode']
      ].forEach(([input, obj, key]) => {
        const group = input.closest('.form-group');
        const ok = input.value.trim().length > 0;
        group.classList.toggle('has-error', !ok);
        if (ok) obj[key] = input.value.trim();
        valid = valid && ok;
      });
    }

    return valid;
  }

  /* --------------------------------------------------------------------
     ORDER SUMMARY (rendered once, shared across all steps)
     -------------------------------------------------------------------- */
  function subtotal() {
    return items.reduce((sum, item) => sum + item.price * item.qty, 0);
  }

  function shippingCost() {
    const sub = subtotal();
    if (sub >= FREE_SHIPPING_THRESHOLD) return 0;
    if (appliedCoupon && appliedCoupon.type === 'shipping') return 0;
    if (state.delivery === 'express') return 500;
    const estimate = CITY_ESTIMATES[state.shipping.city];
    return estimate ? estimate.cost : 250;
  }

  function discount() {
    if (appliedCoupon && appliedCoupon.type === 'percent') {
      return Math.round(subtotal() * (appliedCoupon.value / 100));
    }
    return 0;
  }

  function total() {
    return Math.max(0, subtotal() - discount() + shippingCost());
  }

  function renderSummary() {
    const summaryItemsEl = document.getElementById('order-summary-items');
    if (summaryItemsEl) {
      summaryItemsEl.innerHTML = items
        .map(
          (item) =>
            '<div class="order-summary-item">' +
            '<img src="' + item.image + '" alt="' + item.name + '">' +
            '<div class="order-summary-item-info"><h4>' + item.name + '</h4><span>' + (item.size ? 'Size ' + item.size : '') + ' × ' + item.qty + '</span></div>' +
            '<div class="order-summary-item-price">' + formatPKR(item.price * item.qty) + '</div>' +
            '</div>'
        )
        .join('');
    }

    document.getElementById('summary-subtotal').textContent = formatPKR(subtotal());
    document.getElementById('summary-shipping').textContent = shippingCost() === 0 ? 'Free' : formatPKR(shippingCost());
    document.getElementById('summary-total').textContent = formatPKR(total());

    const discountRow = document.getElementById('summary-discount-row');
    if (discount() > 0) {
      discountRow.style.display = '';
      document.getElementById('summary-discount').textContent = '-' + formatPKR(discount());
    } else {
      discountRow.style.display = 'none';
    }

    if (appliedCoupon) {
      const appliedEl = document.getElementById('coupon-applied');
      const labelEl = document.getElementById('coupon-applied-label');
      if (appliedEl) appliedEl.classList.add('is-visible');
      if (labelEl) labelEl.textContent = appliedCoupon.label + ' applied';
    }
  }

  /* --------------------------------------------------------------------
     STEP: BILLING (also collects shipping address on the same panel —
     kept together since Pakistan COD orders ship to the billing contact
     in the overwhelming majority of cases; a "ship to different address"
     toggle can be added later without restructuring this step)
     -------------------------------------------------------------------- */
  document.getElementById('step-billing-next').addEventListener('click', () => {
    if (validateStep('billing')) goToStep(1);
  });

  /* --------------------------------------------------------------------
     STEP: DELIVERY METHOD
     -------------------------------------------------------------------- */
  document.querySelectorAll('input[name="delivery-method"]').forEach((radio) => {
    radio.addEventListener('change', () => {
      state.delivery = radio.value;
      document.querySelectorAll('#step-delivery .radio-card').forEach((card) => {
        card.classList.toggle('is-selected', card.querySelector('input').checked);
      });
      renderSummary();
    });
  });
  document.getElementById('step-delivery-back').addEventListener('click', () => goToStep(0));
  document.getElementById('step-delivery-next').addEventListener('click', () => goToStep(2));

  /* --------------------------------------------------------------------
     STEP: PAYMENT METHOD
     -------------------------------------------------------------------- */
  document.querySelectorAll('input[name="payment-method"]').forEach((radio) => {
    radio.addEventListener('change', () => {
      state.payment = radio.value;
      document.querySelectorAll('#step-payment .radio-card').forEach((card) => {
        card.classList.toggle('is-selected', card.querySelector('input').checked);
      });
    });
  });
  document.getElementById('step-payment-back').addEventListener('click', () => goToStep(1));
  document.getElementById('step-payment-next').addEventListener('click', () => {
    populateReview();
    goToStep(3);
  });

  /* --------------------------------------------------------------------
     STEP: REVIEW + ORDER NOTES + PLACE ORDER
     -------------------------------------------------------------------- */
  function populateReview() {
    document.getElementById('review-name').textContent = state.billing.firstName + ' ' + state.billing.lastName;
    document.getElementById('review-contact').textContent = state.billing.email + ' · ' + state.billing.phone;
    document.getElementById('review-address').textContent = state.shipping.address + ', ' + state.shipping.city + ' ' + state.shipping.postalCode;
    document.getElementById('review-delivery').textContent = state.delivery === 'express' ? 'Express (1-2 days)' : 'Standard (2-5 days)';

    const paymentLabels = {
      cod: 'Cash on Delivery',
      jazzcash: 'JazzCash',
      easypaisa: 'EasyPaisa',
      card: 'Visa / Mastercard',
      googlepay: 'Google Pay',
      applepay: 'Apple Pay',
      bank: 'Bank Transfer'
    };
    document.getElementById('review-payment').textContent = paymentLabels[state.payment] || state.payment;
  }

  document.getElementById('step-review-back').addEventListener('click', () => goToStep(2));

  const orderNotesInput = document.getElementById('order-notes');
  const placeOrderBtn = document.getElementById('place-order-btn');

  placeOrderBtn.addEventListener('click', () => {
    state.notes = orderNotesInput.value.trim();
    placeOrderBtn.disabled = true;
    placeOrderBtn.querySelector('span').textContent = 'Placing Order…';

    // Simulated processing delay — no real payment gateway yet (Phase 3
    // scope is UI + architecture only), but a brief delay keeps the flow
    // feeling like a real submission rather than an instant, jarring jump.
    setTimeout(() => {
      const order = window.SharlanOrders
        ? window.SharlanOrders.add({
            items: items,
            subtotal: subtotal(),
            shipping: shippingCost(),
            discount: discount(),
            total: total(),
            billing: state.billing,
            shippingAddress: state.shipping,
            deliveryMethod: state.delivery,
            paymentMethod: state.payment,
            notes: state.notes
          })
        : { id: 'SHR-000000' };

      // Save the address for the account dashboard if the shopper is signed in
      if (window.SharlanAddresses && window.SharlanAuth && window.SharlanAuth.isLoggedIn()) {
        window.SharlanAddresses.add({
          label: 'Checkout — ' + state.shipping.city,
          name: state.billing.firstName + ' ' + state.billing.lastName,
          phone: state.billing.phone,
          address: state.shipping.address,
          city: state.shipping.city,
          postalCode: state.shipping.postalCode,
          isDefault: window.SharlanAddresses.getAll().length === 0
        });
      }

      // Clear the cart and any applied coupon now that the order is placed
      if (window.SharlanCart) window.SharlanCart.clear();
      try {
        sessionStorage.removeItem('sharlan_applied_coupon');
      } catch (e) {
        /* no-op */
      }

      document.getElementById('confirmation-order-id').textContent = order.id;
      document.getElementById('confirmation-total').textContent = formatPKR(total());
      goToStep(STEPS.length); // moves past the last real step
      document.getElementById('checkout-steps-wrap').style.display = 'none';
      document.getElementById('order-summary-wrap').style.display = 'none';
      document.getElementById('checkout-stepper').style.display = 'none';
      document.getElementById('order-confirmation').style.display = '';
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }, 900);
  });

  /* --------------------------------------------------------------------
     COUPON (same demo codes as the cart page)
     -------------------------------------------------------------------- */
  const COUPONS = {
    WINTER10: { type: 'percent', value: 10, label: '10% off' },
    FREESHIP: { type: 'shipping', value: 0, label: 'Free shipping' }
  };

  const couponInput = document.getElementById('coupon-input');
  const couponApplyBtn = document.getElementById('coupon-apply-btn');
  const couponRemoveBtn = document.getElementById('coupon-remove-btn');

  if (couponApplyBtn) {
    couponApplyBtn.addEventListener('click', () => {
      const code = (couponInput.value || '').trim().toUpperCase();
      const coupon = COUPONS[code];
      if (!coupon) {
        if (window.SharlanToast) window.SharlanToast.show("That coupon code isn't valid.", 'error');
        return;
      }
      appliedCoupon = coupon;
      renderSummary();
      if (window.SharlanToast) window.SharlanToast.show('Coupon applied', 'success');
    });
  }

  if (couponRemoveBtn) {
    couponRemoveBtn.addEventListener('click', () => {
      appliedCoupon = null;
      document.getElementById('coupon-applied').classList.remove('is-visible');
      couponInput.value = '';
      renderSummary();
    });
  }

  /* --------------------------------------------------------------------
     PRE-FILL FROM SIGNED-IN ACCOUNT (if any) — small UX win, entirely
     optional since guest checkout is fully supported
     -------------------------------------------------------------------- */
  if (window.SharlanAuth && window.SharlanAuth.isLoggedIn()) {
    const user = window.SharlanAuth.getCurrentUser();
    if (user) {
      const [firstName, ...rest] = user.name.split(' ');
      document.getElementById('billing-firstName').value = firstName || '';
      document.getElementById('billing-lastName').value = rest.join(' ') || '';
      document.getElementById('billing-email').value = user.email || '';
      document.getElementById('billing-phone').value = user.phone || '';
    }
    if (window.SharlanAddresses) {
      const defaultAddr = window.SharlanAddresses.getDefault();
      if (defaultAddr) {
        document.getElementById('shipping-address').value = defaultAddr.address || '';
        document.getElementById('shipping-city').value = defaultAddr.city || '';
        document.getElementById('shipping-postal').value = defaultAddr.postalCode || '';
      }
    }
  }

  renderSummary();
  goToStep(0);
})();
