/* ==========================================================================
   SHARLAN — AUTH-STORE.JS
   A demo authentication layer backed by localStorage. There is no real
   backend yet, so passwords are stored in plain text in the browser's
   localStorage purely to simulate the UX flow — this is NOT secure and
   must be replaced with a real authenticated backend (hashed passwords,
   server-side sessions) before this site handles real customers. Flagged
   clearly here and in the README.
   ========================================================================== */

(function () {
  'use strict';

  const USERS_KEY = 'sharlan_users_demo_v1';
  const SESSION_KEY = 'sharlan_session_v1';

  function getUsers() {
    try {
      return JSON.parse(localStorage.getItem(USERS_KEY)) || [];
    } catch (e) {
      return [];
    }
  }

  function saveUsers(users) {
    try {
      localStorage.setItem(USERS_KEY, JSON.stringify(users));
    } catch (e) {
      /* localStorage unavailable */
    }
  }

  function getSession() {
    try {
      return JSON.parse(localStorage.getItem(SESSION_KEY));
    } catch (e) {
      return null;
    }
  }

  function setSession(email) {
    try {
      localStorage.setItem(SESSION_KEY, JSON.stringify({ email: email }));
    } catch (e) {
      /* no-op */
    }
  }

  function clearSession() {
    try {
      localStorage.removeItem(SESSION_KEY);
    } catch (e) {
      /* no-op */
    }
  }

  function register(data) {
    const users = getUsers();
    const exists = users.some((u) => u.email.toLowerCase() === data.email.toLowerCase());
    if (exists) {
      return { success: false, error: 'An account with this email already exists.' };
    }
    users.push({
      name: data.name,
      email: data.email,
      phone: data.phone || '',
      password: data.password // demo only — see file header
    });
    saveUsers(users);
    setSession(data.email);
    return { success: true };
  }

  function login(email, password) {
    const users = getUsers();
    const user = users.find((u) => u.email.toLowerCase() === email.toLowerCase());
    if (!user || user.password !== password) {
      return { success: false, error: 'Incorrect email or password.' };
    }
    setSession(email);
    return { success: true };
  }

  function logout() {
    clearSession();
  }

  function getCurrentUser() {
    const session = getSession();
    if (!session) return null;
    const users = getUsers();
    return users.find((u) => u.email.toLowerCase() === session.email.toLowerCase()) || null;
  }

  function isLoggedIn() {
    return !!getSession();
  }

  function updateUser(email, updates) {
    const users = getUsers();
    const idx = users.findIndex((u) => u.email.toLowerCase() === email.toLowerCase());
    if (idx === -1) return false;
    users[idx] = Object.assign({}, users[idx], updates);
    saveUsers(users);
    return true;
  }

  /* Seed one demo account so Login has something real to test with,
     without forcing every reviewer to register first. */
  function seedDemoAccountIfEmpty() {
    try {
      if (localStorage.getItem(USERS_KEY) !== null) return;
    } catch (e) {
      return;
    }
    saveUsers([{ name: 'Demo Customer', email: 'demo@sharlan.pk', phone: '+92 300 1234567', password: 'demo1234' }]);
  }

  window.SharlanAuth = {
    register: register,
    login: login,
    logout: logout,
    getCurrentUser: getCurrentUser,
    isLoggedIn: isLoggedIn,
    updateUser: updateUser,
    seedDemoIfEmpty: seedDemoAccountIfEmpty
  };
})();
