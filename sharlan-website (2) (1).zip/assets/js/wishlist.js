/* ==========================================================================
   SHARLAN — WISHLIST.JS
   Renders whatever products the person has wishlisted from the Shop,
   product detail, or homepage pages (shared localStorage key).
   ========================================================================== */

(function () {
  'use strict';

  const ALL_PRODUCTS = window.SHARLAN_PRODUCTS || [];
  const WISHLIST_KEY = 'sharlan_wishlist_v1';

  function formatPKR(amount) {
    return 'Rs. ' + Number(amount).toLocaleString('en-PK');
  }

  function getWishlist() {
    try {
      return JSON.parse(localStorage.getItem(WISHLIST_KEY)) || [];
    } catch (e) {
      return [];
    }
  }

  function removeFromWishlist(id) {
    const list = getWishlist().filter((x) => x !== id);
    localStorage.setItem(WISHLIST_KEY, JSON.stringify(list));
  }

  const grid = document.getElementById('wishlist-grid');
  const emptyState = document.getElementById('wishlist-empty');
  const countEl = document.getElementById('wishlist-count');

  function productCardHTML(p) {
    return (
      '<div class="product-card reveal is-visible" data-product-id="' + p.id + '" data-product-name="' + p.name + '" data-product-price="' + p.price + '" data-product-image="' + p.images[0] + '">' +
      '<a href="product.html?id=' + p.id + '" class="product-img-container" style="display:block;">' +
      '<img class="img-base" src="' + p.images[0] + '" alt="' + p.name + '" loading="lazy" width="500" height="600">' +
      '<img class="img-hover" src="' + (p.images[1] || p.images[0]) + '" alt="" loading="lazy" width="500" height="600">' +
      '</a>' +
      '<div class="product-quick-actions">' +
      '<button type="button" class="quick-action-btn is-active" data-wishlist-remove="' + p.id + '" aria-label="Remove from wishlist"><i class="fa-solid fa-heart"></i></button>' +
      '</div>' +
      '<div class="product-info">' +
      '<span class="product-category">' + p.category + '</span>' +
      '<h3><a href="product.html?id=' + p.id + '">' + p.name + '</a></h3>' +
      '<div class="product-price-row"><span class="price">' + formatPKR(p.price) + '</span></div>' +
      '<button type="button" class="btn btn-block add-to-cart"><span>Add to Cart</span></button>' +
      '</div>' +
      '</div>'
    );
  }

  function render() {
    const ids = getWishlist();
    const items = ids.map((id) => ALL_PRODUCTS.find((p) => p.id === id)).filter(Boolean);

    if (countEl) countEl.textContent = items.length + (items.length === 1 ? ' item' : ' items');

    if (!items.length) {
      if (grid) grid.innerHTML = '';
      if (emptyState) emptyState.style.display = '';
      return;
    }

    if (emptyState) emptyState.style.display = 'none';
    if (grid) grid.innerHTML = items.map(productCardHTML).join('');
  }

  if (grid) {
    grid.addEventListener('click', (e) => {
      const removeBtn = e.target.closest('[data-wishlist-remove]');
      const addToCartBtn = e.target.closest('.add-to-cart');

      if (removeBtn) {
        removeFromWishlist(removeBtn.dataset.wishlistRemove);
        if (window.SharlanToast) window.SharlanToast.show('Removed from wishlist', 'info');
        render();
        return;
      }

      if (addToCartBtn) {
        const card = addToCartBtn.closest('[data-product-id]');
        if (card && window.SharlanCart) {
          window.SharlanCart.add({
            id: card.dataset.productId,
            name: card.dataset.productName,
            price: Number(card.dataset.productPrice),
            image: card.dataset.productImage,
            size: null
          });
          if (window.SharlanToast) window.SharlanToast.show(card.dataset.productName + ' added to your bag', 'success');
        }
      }
    });
  }

  render();
})();
