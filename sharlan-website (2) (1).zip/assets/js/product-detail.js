/* ==========================================================================
   SHARLAN — PRODUCT-DETAIL.JS
   Reads a ?id= query param, finds the matching product in
   window.SHARLAN_PRODUCTS, and renders the full product detail page:
   gallery + zoom, size/color selection, tabs (description/specs/delivery/
   reviews), related products, frequently bought together, recently viewed.
   ========================================================================== */

(function () {
  'use strict';

  const ALL_PRODUCTS = window.SHARLAN_PRODUCTS || [];
  const params = new URLSearchParams(window.location.search);
  const productId = params.get('id');
  const product = ALL_PRODUCTS.find((p) => p.id === productId) || ALL_PRODUCTS[0];

  function formatPKR(amount) {
    return 'Rs. ' + Number(amount).toLocaleString('en-PK');
  }

  if (!product) {
    document.getElementById('main-content').innerHTML =
      '<div class="container" style="padding:96px 0;text-align:center;"><h1>Product not found</h1><p style="margin-top:12px;"><a href="shop.html" class="btn" style="margin-top:24px;display:inline-flex;"><span>Back to Shop</span></a></p></div>';
    return;
  }

  /* --------------------------------------------------------------------
     RECENTLY VIEWED (localStorage, capped at 8 items, most recent first)
     -------------------------------------------------------------------- */
  const RECENT_KEY = 'sharlan_recently_viewed_v1';

  function pushRecentlyViewed(id) {
    try {
      let list = JSON.parse(localStorage.getItem(RECENT_KEY)) || [];
      list = list.filter((x) => x !== id);
      list.unshift(id);
      list = list.slice(0, 8);
      localStorage.setItem(RECENT_KEY, JSON.stringify(list));
    } catch (e) {
      /* localStorage unavailable — recently viewed just won't persist */
    }
  }

  function getRecentlyViewed() {
    try {
      return JSON.parse(localStorage.getItem(RECENT_KEY)) || [];
    } catch (e) {
      return [];
    }
  }

  pushRecentlyViewed(product.id);

  /* --------------------------------------------------------------------
     WISHLIST
     -------------------------------------------------------------------- */
  function getWishlist() {
    try {
      return JSON.parse(localStorage.getItem('sharlan_wishlist_v1')) || [];
    } catch (e) {
      return [];
    }
  }

  function toggleWishlist(id) {
    let list = getWishlist();
    const idx = list.indexOf(id);
    if (idx > -1) list.splice(idx, 1);
    else list.push(id);
    localStorage.setItem('sharlan_wishlist_v1', JSON.stringify(list));
    return list.includes(id);
  }

  /* --------------------------------------------------------------------
     PAGE META
     -------------------------------------------------------------------- */
  document.title = product.name + ' | SHARLAN';
  const metaDesc = document.querySelector('meta[name="description"]');
  if (metaDesc) metaDesc.setAttribute('content', product.description);

  const canonicalUrl = 'https://www.sharlan.pk/pages/product.html?id=' + product.id;
  const canonicalLink = document.getElementById('canonical-link');
  if (canonicalLink) canonicalLink.setAttribute('href', canonicalUrl);

  const ogTitle = document.getElementById('og-title');
  const ogDesc = document.getElementById('og-description');
  const ogImage = document.getElementById('og-image');
  const ogUrl = document.getElementById('og-url');
  const twitterTitle = document.getElementById('twitter-title');
  const twitterImage = document.getElementById('twitter-image');
  const titleText = product.name + ' | SHARLAN';
  if (ogTitle) ogTitle.setAttribute('content', titleText);
  if (twitterTitle) twitterTitle.setAttribute('content', titleText);
  if (ogDesc) ogDesc.setAttribute('content', product.description);
  if (ogImage) ogImage.setAttribute('content', product.images[0]);
  if (twitterImage) twitterImage.setAttribute('content', product.images[0]);
  if (ogUrl) ogUrl.setAttribute('content', canonicalUrl);

  const breadcrumbCat = document.getElementById('breadcrumb-category');
  if (breadcrumbCat) {
    breadcrumbCat.textContent = product.category.charAt(0).toUpperCase() + product.category.slice(1);
    breadcrumbCat.href = 'shop.html?category=' + product.category;
  }
  const breadcrumbName = document.getElementById('breadcrumb-product-name');
  if (breadcrumbName) breadcrumbName.textContent = product.name;

  /* --------------------------------------------------------------------
     STRUCTURED DATA (Product schema, filled in after we know the product)
     -------------------------------------------------------------------- */
  const ldJson = document.getElementById('product-ld-json');
  if (ldJson) {
    ldJson.textContent = JSON.stringify({
      '@context': 'https://schema.org',
      '@type': 'Product',
      name: product.name,
      description: product.description,
      image: product.images,
      sku: product.id,
      brand: { '@type': 'Brand', name: 'SHARLAN' },
      offers: {
        '@type': 'Offer',
        priceCurrency: 'PKR',
        price: product.price,
        availability: product.stock === 'out_of_stock' ? 'https://schema.org/OutOfStock' : 'https://schema.org/InStock'
      },
      aggregateRating: {
        '@type': 'AggregateRating',
        ratingValue: product.rating,
        reviewCount: product.reviewCount
      }
    });
  }

  /* --------------------------------------------------------------------
     GALLERY
     -------------------------------------------------------------------- */
  let activeImageIndex = 0;
  const galleryMain = document.getElementById('gallery-main-img');
  const galleryMainWrap = document.getElementById('gallery-main');
  const galleryThumbsWrap = document.getElementById('gallery-thumbs');

  function renderGallery() {
    if (galleryMain) galleryMain.src = product.images[activeImageIndex];
    if (galleryThumbsWrap) {
      galleryThumbsWrap.innerHTML = product.images
        .map(
          (img, i) =>
            '<button type="button" class="gallery-thumb' + (i === activeImageIndex ? ' active' : '') + '" data-thumb-index="' + i + '"><img src="' + img + '" alt="' + product.name + ' view ' + (i + 1) + '"></button>'
        )
        .join('');
    }
  }

  if (galleryThumbsWrap) {
    galleryThumbsWrap.addEventListener('click', (e) => {
      const btn = e.target.closest('[data-thumb-index]');
      if (!btn) return;
      activeImageIndex = Number(btn.dataset.thumbIndex);
      renderGallery();
    });
  }

  // Click-to-zoom toggle on the main image (desktop-friendly; disabled on small screens via CSS)
  if (galleryMainWrap) {
    galleryMainWrap.addEventListener('click', () => {
      if (window.innerWidth > 600) galleryMainWrap.classList.toggle('is-zoomed');
    });
  }

  renderGallery();

  /* --------------------------------------------------------------------
     INFO PANEL
     -------------------------------------------------------------------- */
  document.getElementById('pd-category').textContent = product.category;
  document.getElementById('pd-name').textContent = product.name;
  document.getElementById('pd-price').textContent = formatPKR(product.price);

  if (product.originalPrice) {
    const originalEl = document.getElementById('pd-price-original');
    originalEl.textContent = formatPKR(product.originalPrice);
    originalEl.style.display = '';
  }

  document.getElementById('pd-description').textContent = product.description;

  // Color selector
  let selectedColor = product.colors[0].name;
  const colorGroup = document.getElementById('pd-color-group');
  const colorSelectedLabel = document.getElementById('pd-color-selected');
  if (colorGroup) {
    colorGroup.innerHTML = product.colors
      .map(
        (c, i) =>
          '<button type="button" class="color-swatch" style="background:' + c.hex + (c.hex === '#f4f6f8' ? ';border:1px solid #ddd' : '') + '" data-color="' + c.name + '" aria-pressed="' + (i === 0 ? 'true' : 'false') + '" title="' + c.name + '"></button>'
      )
      .join('');
    if (colorSelectedLabel) colorSelectedLabel.textContent = selectedColor;

    colorGroup.addEventListener('click', (e) => {
      const btn = e.target.closest('[data-color]');
      if (!btn) return;
      selectedColor = btn.dataset.color;
      colorGroup.querySelectorAll('[data-color]').forEach((b) => b.setAttribute('aria-pressed', String(b === btn)));
      if (colorSelectedLabel) colorSelectedLabel.textContent = selectedColor;
    });
  }

  // Size selector
  let selectedSize = product.sizes ? product.sizes[0] : null;
  const sizeGroupWrap = document.getElementById('pd-size-group-wrap');
  const sizeGroup = document.getElementById('pd-size-group');
  const sizeSelectedLabel = document.getElementById('pd-size-selected');

  if (product.sizes && sizeGroup) {
    sizeGroupWrap.style.display = '';
    sizeGroup.innerHTML = product.sizes
      .map((s, i) => '<span class="size-chip" data-size="' + s + '" aria-pressed="' + (i === 0 ? 'true' : 'false') + '">' + s + '</span>')
      .join('');
    if (sizeSelectedLabel) sizeSelectedLabel.textContent = selectedSize;

    sizeGroup.addEventListener('click', (e) => {
      const chip = e.target.closest('[data-size]');
      if (!chip) return;
      selectedSize = chip.dataset.size;
      sizeGroup.querySelectorAll('[data-size]').forEach((c) => c.setAttribute('aria-pressed', String(c === chip)));
      if (sizeSelectedLabel) sizeSelectedLabel.textContent = selectedSize;
    });
  } else if (sizeGroupWrap) {
    sizeGroupWrap.style.display = 'none';
  }

  // Quantity selector
  let qty = 1;
  const qtyDisplay = document.getElementById('pd-qty-display');
  document.getElementById('pd-qty-decrease').addEventListener('click', () => {
    qty = Math.max(1, qty - 1);
    qtyDisplay.textContent = qty;
  });
  document.getElementById('pd-qty-increase').addEventListener('click', () => {
    qty = Math.min(10, qty + 1);
    qtyDisplay.textContent = qty;
  });

  // Stock status — not shown yet: real inventory isn't connected to a
  // backend, so displaying "In Stock"/"Low Stock" here would be a claim
  // we can't actually back up. "Add to Cart" stays enabled for every
  // demo product; real availability is confirmed manually over WhatsApp
  // once an order request comes in.
  const stockEl = document.getElementById('pd-stock-status');
  const addToCartBtn = document.getElementById('pd-add-to-cart');
  if (stockEl) stockEl.style.display = 'none';

  // Add to cart
  addToCartBtn.addEventListener('click', () => {
    if (window.SharlanCart) {
      for (let i = 0; i < qty; i++) {
        window.SharlanCart.add({
          id: product.id,
          name: product.name,
          price: product.price,
          image: product.images[0],
          size: selectedSize
        });
      }
    }
    if (window.SharlanToast) {
      window.SharlanToast.show(qty + '× ' + product.name + ' added to your bag', 'success');
    }
  });

  // Wishlist button
  const wishlistBtn = document.getElementById('pd-wishlist-btn');
  const isWishlisted = getWishlist().includes(product.id);
  wishlistBtn.classList.toggle('is-active', isWishlisted);
  wishlistBtn.querySelector('i').className = isWishlisted ? 'fa-solid fa-heart' : 'fa-regular fa-heart';
  wishlistBtn.setAttribute('aria-label', isWishlisted ? 'Remove from wishlist' : 'Add to wishlist');

  wishlistBtn.addEventListener('click', () => {
    const active = toggleWishlist(product.id);
    wishlistBtn.classList.toggle('is-active', active);
    wishlistBtn.querySelector('i').className = active ? 'fa-solid fa-heart' : 'fa-regular fa-heart';
    wishlistBtn.setAttribute('aria-label', active ? 'Remove from wishlist' : 'Add to wishlist');
    if (window.SharlanToast) {
      window.SharlanToast.show(active ? 'Added to wishlist' : 'Removed from wishlist', active ? 'success' : 'info');
    }
  });

  /* --------------------------------------------------------------------
     SIZE GUIDE MODAL
     -------------------------------------------------------------------- */
  const SIZE_GUIDES = {
    jackets: {
      headers: ['Size', 'Chest (in)', 'Length (in)'],
      rows: [['S', '38-40', '27'], ['M', '40-42', '28'], ['L', '42-44', '29'], ['XL', '44-46', '30'], ['XXL', '46-48', '31']]
    },
    sneakers: {
      headers: ['UK', 'EU', 'US'],
      rows: [['UK 6', '40', '7'], ['UK 7', '41', '8'], ['UK 8', '42', '9'], ['UK 9', '43', '10'], ['UK 10', '44', '11'], ['UK 11', '45', '12']]
    },
    jeans: {
      headers: ['Waist (in)', 'Inseam (in)'],
      rows: [['28', '30'], ['30', '31'], ['32', '32'], ['34', '32'], ['36', '33'], ['38', '33']]
    },
    watches: {
      headers: ['Fit', 'Wrist (cm)'],
      rows: [['One Size', '14-19']]
    }
  };

  const sizeGuideTrigger = document.getElementById('size-guide-trigger');
  const sizeGuideOverlay = document.getElementById('size-guide-overlay');
  const sizeGuideClose = document.getElementById('size-guide-close');
  const sizeGuideTable = document.getElementById('size-guide-table');
  const sizeGuideTrapHandler = window.SharlanA11y ? window.SharlanA11y.trapFocus(sizeGuideOverlay) : () => {};

  if (sizeGuideTrigger) {
    sizeGuideTrigger.addEventListener('click', () => {
      const guide = SIZE_GUIDES[product.category];
      if (guide && sizeGuideTable) {
        sizeGuideTable.innerHTML =
          '<tr>' + guide.headers.map((h) => '<td style="font-weight:700;">' + h + '</td>').join('') + '</tr>' +
          guide.rows.map((row) => '<tr>' + row.map((cell) => '<td>' + cell + '</td>').join('') + '</tr>').join('');
      }
      sizeGuideOverlay.classList.add('is-open');
      document.body.style.overflow = 'hidden';
      document.addEventListener('keydown', sizeGuideTrapHandler);
      sizeGuideClose.focus();
    });
  }

  function closeSizeGuide() {
    sizeGuideOverlay.classList.remove('is-open');
    document.body.style.overflow = '';
    document.removeEventListener('keydown', sizeGuideTrapHandler);
    if (sizeGuideTrigger) sizeGuideTrigger.focus();
  }

  if (sizeGuideClose) sizeGuideClose.addEventListener('click', closeSizeGuide);
  if (sizeGuideOverlay) {
    sizeGuideOverlay.addEventListener('click', (e) => {
      if (e.target === sizeGuideOverlay) closeSizeGuide();
    });
  }
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && sizeGuideOverlay && sizeGuideOverlay.classList.contains('is-open')) closeSizeGuide();
  });

  /* --------------------------------------------------------------------
     TABS
     -------------------------------------------------------------------- */
  document.getElementById('pd-tab-material').textContent = product.material;
  document.getElementById('pd-tab-category-spec').textContent = product.category;
  document.getElementById('pd-tab-sizes-spec').textContent = product.sizes ? product.sizes.join(', ') : 'One size';
  document.getElementById('pd-tab-colors-spec').textContent = product.colors.map((c) => c.name).join(', ');

  const reviewSummaryEl = document.getElementById('pd-review-summary');
  const reviewEmptyEl = document.getElementById('pd-review-empty');
  if (reviewSummaryEl) reviewSummaryEl.style.display = 'none';
  if (reviewEmptyEl) reviewEmptyEl.style.display = '';

  document.querySelectorAll('.pd-tab-btn').forEach((btn) => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.pd-tab-btn').forEach((b) => b.classList.toggle('active', b === btn));
      document.querySelectorAll('.pd-tab-panel').forEach((p) => p.classList.toggle('active', p.id === btn.dataset.tabTarget));
    });
  });

  /* --------------------------------------------------------------------
     RELATED PRODUCTS (same category, excluding this product)
     -------------------------------------------------------------------- */
  function productCardHTML(p) {
    return (
      '<div class="product-card reveal is-visible" data-product-id="' + p.id + '" data-product-name="' + p.name + '" data-product-price="' + p.price + '" data-product-image="' + p.images[0] + '">' +
      '<a href="product.html?id=' + p.id + '" class="product-img-container" style="display:block;">' +
      '<img class="img-base" src="' + p.images[0] + '" alt="' + p.name + '" loading="lazy" width="500" height="600">' +
      '<img class="img-hover" src="' + (p.images[1] || p.images[0]) + '" alt="" loading="lazy" width="500" height="600">' +
      '</a>' +
      '<div class="product-info">' +
      '<span class="product-category">' + p.category + '</span>' +
      '<h3><a href="product.html?id=' + p.id + '">' + p.name + '</a></h3>' +
      '<div class="product-price-row"><span class="price">' + formatPKR(p.price) + '</span></div>' +
      '<button type="button" class="btn btn-block add-to-cart"><span>Add to Cart</span></button>' +
      '</div>' +
      '</div>'
    );
  }

  const relatedGrid = document.getElementById('related-products-grid');
  if (relatedGrid) {
    const related = ALL_PRODUCTS.filter((p) => p.category === product.category && p.id !== product.id).slice(0, 4);
    relatedGrid.innerHTML = related.length
      ? related.map(productCardHTML).join('')
      : '<p style="color:var(--color-text-muted);">No related products yet.</p>';
  }

  /* --------------------------------------------------------------------
     RECENTLY VIEWED
     -------------------------------------------------------------------- */
  const recentGrid = document.getElementById('recently-viewed-grid');
  const recentSection = document.getElementById('recently-viewed-section');
  if (recentGrid) {
    const recentIds = getRecentlyViewed().filter((id) => id !== product.id);
    const recentProducts = recentIds.map((id) => ALL_PRODUCTS.find((p) => p.id === id)).filter(Boolean).slice(0, 4);
    if (recentProducts.length) {
      recentGrid.innerHTML = recentProducts.map(productCardHTML).join('');
    } else if (recentSection) {
      recentSection.style.display = 'none';
    }
  }

  /* --------------------------------------------------------------------
     FREQUENTLY BOUGHT TOGETHER (this item + 2 others from the catalog)
     -------------------------------------------------------------------- */
  const fbtGrid = document.getElementById('fbt-grid');
  const fbtTotalEl = document.getElementById('fbt-total-price');
  const fbtAddBtn = document.getElementById('fbt-add-btn');

  if (fbtGrid) {
    const companions = ALL_PRODUCTS.filter((p) => p.category !== product.category).slice(0, 2);
    const bundle = [product, ...companions];

    fbtGrid.innerHTML = bundle
      .map(
        (p, i) =>
          (i > 0 ? '<span class="fbt-plus">+</span>' : '') +
          '<div class="fbt-item"><img src="' + p.images[0] + '" alt="' + p.name + '"><div><div class="fbt-name">' + p.name + '</div><div class="fbt-price">' + formatPKR(p.price) + '</div></div></div>'
      )
      .join('');

    const total = bundle.reduce((sum, p) => sum + p.price, 0);
    if (fbtTotalEl) fbtTotalEl.textContent = formatPKR(total);

    if (fbtAddBtn) {
      fbtAddBtn.addEventListener('click', () => {
        if (window.SharlanCart) {
          bundle.forEach((p) => window.SharlanCart.add({ id: p.id, name: p.name, price: p.price, image: p.images[0], size: null }));
        }
        if (window.SharlanToast) window.SharlanToast.show('Bundle added to your bag', 'success');
      });
    }
  }

  /* --------------------------------------------------------------------
     DELEGATED CLICKS FOR RELATED / RECENTLY VIEWED "ADD TO CART"
     -------------------------------------------------------------------- */
  document.querySelectorAll('#related-products-grid, #recently-viewed-grid').forEach((grid) => {
    grid.addEventListener('click', (e) => {
      const btn = e.target.closest('.add-to-cart');
      if (!btn) return;
      const card = btn.closest('[data-product-id]');
      if (card && window.SharlanCart) {
        window.SharlanCart.add({
          id: card.dataset.productId,
          name: card.dataset.productName,
          price: Number(card.dataset.productPrice),
          image: card.dataset.productImage,
          size: null
        });
        if (window.SharlanToast) window.SharlanToast.show(card.dataset.productName + ' added to your bag', 'success');
      }
    });
  });
})();
