/* ==========================================================================
   SHARLAN — ACCOUNT.JS
   Drives the Account Dashboard: My Orders, Wishlist, Saved Addresses,
   Account Details, and Password Management. Reads from auth-store.js,
   orders-store.js, addresses-store.js, and the shared wishlist key.
   Redirects to Login if no one is signed in (demo session).
   ========================================================================== */

(function () {
  'use strict';

  if (window.SharlanAuth && window.SharlanAuth.seedDemoIfEmpty) window.SharlanAuth.seedDemoIfEmpty();
  if (window.SharlanOrders && window.SharlanOrders.seedDemoIfEmpty) window.SharlanOrders.seedDemoIfEmpty();

  if (!window.SharlanAuth || !window.SharlanAuth.isLoggedIn()) {
    window.location.href = 'login.html';
    return;
  }

  const user = window.SharlanAuth.getCurrentUser();
  const ALL_PRODUCTS = window.SHARLAN_PRODUCTS || [];

  function formatPKR(amount) {
    return 'Rs. ' + Number(amount).toLocaleString('en-PK');
  }

  function formatDate(iso) {
    return new Date(iso).toLocaleDateString('en-PK', { day: 'numeric', month: 'short', year: 'numeric' });
  }

  /* --------------------------------------------------------------------
     PROFILE CARD + TAB SWITCHING
     -------------------------------------------------------------------- */
  const initials = user.name
    .split(' ')
    .map((w) => w[0])
    .join('')
    .slice(0, 2)
    .toUpperCase();
  document.getElementById('account-avatar').textContent = initials;
  document.getElementById('account-name').textContent = user.name;
  document.getElementById('account-email').textContent = user.email;

  document.querySelectorAll('.account-nav button[data-panel]').forEach((btn) => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.account-nav button[data-panel]').forEach((b) => b.classList.toggle('active', b === btn));
      document.querySelectorAll('.account-panel').forEach((p) => p.classList.toggle('active', p.id === 'panel-' + btn.dataset.panel));
    });
  });

  document.getElementById('logout-btn').addEventListener('click', () => {
    window.SharlanAuth.logout();
    window.location.href = '../index.html';
  });

  /* --------------------------------------------------------------------
     MY ORDERS
     -------------------------------------------------------------------- */
  const statusLabels = { processing: 'Processing', shipped: 'Shipped', delivered: 'Delivered' };
  const ordersListEl = document.getElementById('orders-list');

  function renderOrders() {
    const orders = window.SharlanOrders ? window.SharlanOrders.getAll() : [];
    if (!orders.length) {
      ordersListEl.innerHTML = '<div class="empty-panel-state"><i class="fa-solid fa-box-open"></i><p>No orders yet.</p></div>';
      return;
    }

    ordersListEl.innerHTML = orders
      .map(
        (o) =>
          '<div class="order-list-item">' +
          '<div><div class="order-list-item-id">' + o.id + '</div>' +
          '<div class="order-list-item-meta">' + formatDate(o.date) + ' · ' + o.items.length + ' item' + (o.items.length > 1 ? 's' : '') + ' · ' + formatPKR(o.total) + '</div></div>' +
          '<span class="order-status-badge status-' + o.status + '">' + statusLabels[o.status] + '</span>' +
          '</div>'
      )
      .join('');
  }
  renderOrders();

  /* --------------------------------------------------------------------
     WISHLIST
     -------------------------------------------------------------------- */
  const wishlistGridEl = document.getElementById('account-wishlist-grid');

  function getWishlistIds() {
    try {
      return JSON.parse(localStorage.getItem('sharlan_wishlist_v1')) || [];
    } catch (e) {
      return [];
    }
  }

  function renderWishlist() {
    const ids = getWishlistIds();
    const products = ids.map((id) => ALL_PRODUCTS.find((p) => p.id === id)).filter(Boolean);

    if (!products.length) {
      wishlistGridEl.innerHTML = '<div class="empty-panel-state"><i class="fa-regular fa-heart"></i><p>Your wishlist is empty.</p></div>';
      return;
    }

    wishlistGridEl.innerHTML =
      '<div class="products-grid">' +
      products
        .map(
          (p) =>
            '<div class="product-card">' +
            '<a href="product.html?id=' + p.id + '" class="product-img-container" style="display:block;"><img class="img-base" src="' + p.images[0] + '" alt="' + p.name + '" loading="lazy" width="500" height="600"></a>' +
            '<div class="product-info"><span class="product-category">' + p.category + '</span><h3><a href="product.html?id=' + p.id + '">' + p.name + '</a></h3>' +
            '<div class="product-price-row"><span class="price">' + formatPKR(p.price) + '</span></div></div>' +
            '</div>'
        )
        .join('') +
      '</div>';
  }
  if (wishlistGridEl) renderWishlist();

  /* --------------------------------------------------------------------
     SAVED ADDRESSES
     -------------------------------------------------------------------- */
  const addressesListEl = document.getElementById('addresses-list');

  function renderAddresses() {
    const addresses = window.SharlanAddresses ? window.SharlanAddresses.getAll() : [];
    if (!addresses.length) {
      addressesListEl.innerHTML = '<div class="empty-panel-state"><i class="fa-solid fa-location-dot"></i><p>No saved addresses yet — one is added automatically the first time you check out.</p></div>';
      return;
    }

    addressesListEl.innerHTML = addresses
      .map(
        (a) =>
          '<div class="address-card' + (a.isDefault ? ' is-default' : '') + '" data-address-id="' + a.id + '">' +
          '<strong>' + a.name + '</strong><br>' +
          '<span style="color:var(--color-text-muted);font-size:var(--fs-sm);">' + a.address + ', ' + a.city + ' ' + a.postalCode + '<br>' + a.phone + '</span>' +
          '<div class="address-card-actions"><button type="button" data-remove-address="' + a.id + '">Remove</button></div>' +
          '</div>'
      )
      .join('');
  }
  if (addressesListEl) {
    renderAddresses();
    addressesListEl.addEventListener('click', (e) => {
      const btn = e.target.closest('[data-remove-address]');
      if (!btn || !window.SharlanAddresses) return;
      window.SharlanAddresses.remove(btn.dataset.removeAddress);
      renderAddresses();
      if (window.SharlanToast) window.SharlanToast.show('Address removed', 'info');
    });
  }

  const addAddressForm = document.getElementById('add-address-form');
  if (addAddressForm) {
    addAddressForm.addEventListener('submit', (e) => {
      e.preventDefault();
      const name = document.getElementById('addr-name').value.trim();
      const phone = document.getElementById('addr-phone').value.trim();
      const address = document.getElementById('addr-line').value.trim();
      const city = document.getElementById('addr-city').value;
      const postalCode = document.getElementById('addr-postal').value.trim();

      if (!name || !phone || !address || !city || !postalCode) {
        if (window.SharlanToast) window.SharlanToast.show('Please fill in every field.', 'error');
        return;
      }

      window.SharlanAddresses.add({
        name: name,
        phone: phone,
        address: address,
        city: city,
        postalCode: postalCode,
        isDefault: window.SharlanAddresses.getAll().length === 0
      });

      addAddressForm.reset();
      renderAddresses();
      if (window.SharlanToast) window.SharlanToast.show('Address saved', 'success');
    });
  }

  /* --------------------------------------------------------------------
     ACCOUNT DETAILS
     -------------------------------------------------------------------- */
  const detailsForm = document.getElementById('account-details-form');
  if (detailsForm) {
    document.getElementById('details-name').value = user.name;
    document.getElementById('details-email').value = user.email;
    document.getElementById('details-phone').value = user.phone || '';

    detailsForm.addEventListener('submit', (e) => {
      e.preventDefault();
      const updates = {
        name: document.getElementById('details-name').value.trim(),
        phone: document.getElementById('details-phone').value.trim()
      };
      window.SharlanAuth.updateUser(user.email, updates);
      document.getElementById('account-name').textContent = updates.name;
      if (window.SharlanToast) window.SharlanToast.show('Account details updated', 'success');
    });
  }

  /* --------------------------------------------------------------------
     PASSWORD MANAGEMENT
     -------------------------------------------------------------------- */
  const passwordForm = document.getElementById('change-password-form');
  if (passwordForm) {
    passwordForm.addEventListener('submit', (e) => {
      e.preventDefault();
      const current = document.getElementById('current-password');
      const next = document.getElementById('new-password');
      const confirm = document.getElementById('confirm-new-password');

      if (current.value !== user.password) {
        current.closest('.form-group').classList.add('has-error');
        if (window.SharlanToast) window.SharlanToast.show('Current password is incorrect.', 'error');
        return;
      }
      current.closest('.form-group').classList.remove('has-error');

      if (next.value.length < 8) {
        next.closest('.form-group').classList.add('has-error');
        if (window.SharlanToast) window.SharlanToast.show('New password must be at least 8 characters.', 'error');
        return;
      }
      next.closest('.form-group').classList.remove('has-error');

      if (next.value !== confirm.value) {
        confirm.closest('.form-group').classList.add('has-error');
        if (window.SharlanToast) window.SharlanToast.show('New passwords do not match.', 'error');
        return;
      }
      confirm.closest('.form-group').classList.remove('has-error');

      window.SharlanAuth.updateUser(user.email, { password: next.value });
      user.password = next.value;
      passwordForm.reset();
      if (window.SharlanToast) window.SharlanToast.show('Password updated', 'success');
    });
  }
})();
