/* ==========================================================================
   SHARLAN — SHOP.JS
   Drives the Shop / category listing page: reads window.SHARLAN_PRODUCTS,
   applies URL-driven category/gender/collection context plus interactive
   search/filter/sort, renders the grid, and handles pagination, grid/list
   toggle, quick view, and wishlist toggling.
   ========================================================================== */

(function () {
  'use strict';

  const ALL_PRODUCTS = window.SHARLAN_PRODUCTS || [];
  const PAGE_SIZE = 6;

  const params = new URLSearchParams(window.location.search);

  /* --------------------------------------------------------------------
     STATE
     -------------------------------------------------------------------- */
  const state = {
    category: params.get('category') || null,     // 'jackets' | 'sneakers' | 'jeans' | 'watches'
    gender: params.get('gender') || null,          // 'men' | 'women'
    collection: params.get('collection') || null,  // 'winter' | 'new' | 'best'
    search: params.get('q') || '',
    sort: 'newest',
    colors: new Set(),
    sizes: new Set(),
    maxPrice: null,
    view: 'grid',
    page: 1
  };

  /* --------------------------------------------------------------------
     PAGE TITLE / BREADCRUMB (based on URL context)
     -------------------------------------------------------------------- */
  function pageTitle() {
    if (state.collection === 'new') return 'New Arrivals';
    if (state.collection === 'best') return 'Best Sellers';
    if (state.collection === 'winter') return 'Winter Collection';
    if (state.category) return state.category.charAt(0).toUpperCase() + state.category.slice(1);
    if (state.gender) return state.gender.charAt(0).toUpperCase() + state.gender.slice(1);
    return 'Shop All';
  }

  const titleEl = document.getElementById('shop-title');
  const breadcrumbCurrentEl = document.getElementById('breadcrumb-current');
  if (titleEl) titleEl.textContent = pageTitle();
  if (breadcrumbCurrentEl) breadcrumbCurrentEl.textContent = pageTitle();
  document.title = pageTitle() + ' | SHARLAN';

  // Canonical + Open Graph tags reflect the current filtered view (category/
  // collection pages are meaningfully different content, so each should be
  // independently indexable rather than all pointing at the bare Shop page).
  const canonicalUrl = 'https://www.sharlan.pk/pages/shop.html' + (window.location.search || '');
  const canonicalLink = document.querySelector('link[rel="canonical"]');
  if (canonicalLink) canonicalLink.setAttribute('href', canonicalUrl);
  const ogTitle = document.getElementById('og-title');
  const ogDesc = document.getElementById('og-description');
  const ogUrl = document.getElementById('og-url');
  const twitterTitle = document.getElementById('twitter-title');
  if (ogTitle) ogTitle.setAttribute('content', pageTitle() + ' | SHARLAN');
  if (twitterTitle) twitterTitle.setAttribute('content', pageTitle() + ' | SHARLAN');
  if (ogUrl) ogUrl.setAttribute('content', canonicalUrl);
  if (ogDesc) ogDesc.setAttribute('content', 'Shop ' + pageTitle() + ' at SHARLAN — premium winter streetwear for Pakistan, Cash on Delivery available.');
  const metaDescEl = document.querySelector('meta[name="description"]');
  if (metaDescEl) metaDescEl.setAttribute('content', 'Shop ' + pageTitle() + ' at SHARLAN — premium winter streetwear for Pakistan, Cash on Delivery available.');

  /* --------------------------------------------------------------------
     WISHLIST (shared localStorage key with wishlist.html)
     -------------------------------------------------------------------- */
  function getWishlist() {
    try {
      return JSON.parse(localStorage.getItem('sharlan_wishlist_v1')) || [];
    } catch (e) {
      return [];
    }
  }

  function toggleWishlist(id) {
    let list = getWishlist();
    const idx = list.indexOf(id);
    if (idx > -1) {
      list.splice(idx, 1);
    } else {
      list.push(id);
    }
    localStorage.setItem('sharlan_wishlist_v1', JSON.stringify(list));
    return list.includes(id);
  }

  /* --------------------------------------------------------------------
     FILTERING
     -------------------------------------------------------------------- */
  function applyFilters() {
    let list = ALL_PRODUCTS.slice();

    if (state.category) list = list.filter((p) => p.category === state.category);
    if (state.gender) list = list.filter((p) => p.gender === state.gender || p.gender === 'unisex');
    if (state.collection === 'new') list = list.filter((p) => p.isNew);
    if (state.collection === 'best') list = list.filter((p) => p.isBestSeller);
    if (state.collection === 'winter') list = list.filter((p) => p.collections.includes('winter'));

    if (state.search.trim()) {
      const q = state.search.trim().toLowerCase();
      list = list.filter(
        (p) => p.name.toLowerCase().includes(q) || p.category.toLowerCase().includes(q)
      );
    }

    if (state.colors.size) {
      list = list.filter((p) => p.colors.some((c) => state.colors.has(c.name)));
    }

    if (state.sizes.size) {
      list = list.filter((p) => p.sizes && p.sizes.some((s) => state.sizes.has(s)));
    }

    if (state.maxPrice) {
      list = list.filter((p) => p.price <= state.maxPrice);
    }

    switch (state.sort) {
      case 'price-asc':
        list.sort((a, b) => a.price - b.price);
        break;
      case 'price-desc':
        list.sort((a, b) => b.price - a.price);
        break;
      case 'best-selling':
        list.sort((a, b) => (b.isBestSeller === a.isBestSeller ? b.reviewCount - a.reviewCount : b.isBestSeller - a.isBestSeller));
        break;
      case 'newest':
      default:
        list.sort((a, b) => (b.isNew === a.isNew ? 0 : b.isNew ? 1 : -1));
        break;
    }

    return list;
  }

  /* --------------------------------------------------------------------
     RENDER — PRODUCT GRID + PAGINATION
     -------------------------------------------------------------------- */
  const gridEl = document.getElementById('shop-product-grid');
  const resultCountEl = document.getElementById('result-count');
  const paginationEl = document.getElementById('pagination');
  const activeFiltersEl = document.getElementById('active-filters');

  function formatPKR(amount) {
    return 'Rs. ' + Number(amount).toLocaleString('en-PK');
  }

  function stockLabel(stock) {
    if (stock === 'low_stock') return { text: 'Low Stock', className: 'low-stock', icon: 'fa-triangle-exclamation' };
    if (stock === 'out_of_stock') return { text: 'Out of Stock', className: 'out-of-stock', icon: 'fa-circle-xmark' };
    return { text: 'In Stock', className: 'in-stock', icon: 'fa-circle-check' };
  }

  function productCardHTML(p) {
    const wishlisted = getWishlist().includes(p.id);
    const badge = p.isNew
      ? '<span class="product-badge badge-accent">New</span>'
      : p.originalPrice
      ? '<span class="product-badge badge-sale">-' + Math.round(100 - (p.price / p.originalPrice) * 100) + '%</span>'
      : p.isBestSeller
      ? '<span class="product-badge">Best Seller</span>'
      : '';

    return (
      '<div class="product-card reveal is-visible" data-product-id="' + p.id + '" data-product-name="' + p.name + '" data-product-price="' + p.price + '" data-product-image="' + p.images[0] + '">' +
      '<a href="product.html?id=' + p.id + '" class="product-img-container" style="display:block;">' +
      '<img class="img-base" src="' + p.images[0] + '" alt="' + p.name + '" loading="lazy" width="500" height="600">' +
      '<img class="img-hover" src="' + (p.images[1] || p.images[0]) + '" alt="' + p.name + ', alternate angle" loading="lazy" width="500" height="600">' +
      badge +
      '</a>' +
      '<div class="product-quick-actions">' +
      '<button type="button" class="quick-action-btn' + (wishlisted ? ' is-active' : '') + '" data-wishlist-toggle="' + p.id + '" aria-label="' + (wishlisted ? 'Remove from wishlist' : 'Add to wishlist') + '"><i class="fa-' + (wishlisted ? 'solid' : 'regular') + ' fa-heart"></i></button>' +
      '<button type="button" class="quick-action-btn" data-quickview="' + p.id + '" aria-label="Quick view"><i class="fa-regular fa-eye"></i></button>' +
      '</div>' +
      '<div class="product-info">' +
      '<span class="product-category">' + p.category + '</span>' +
      '<h3><a href="product.html?id=' + p.id + '">' + p.name + '</a></h3>' +
      '<p class="list-description">' + p.description + '</p>' +
      '<div class="product-price-row"><span class="price">' + formatPKR(p.price) + '</span>' +
      (p.originalPrice ? '<span class="price-original">' + formatPKR(p.originalPrice) + '</span>' : '') +
      '</div>' +
      '<button type="button" class="btn btn-block add-to-cart"><span>Add to Cart</span></button>' +
      '</div>' +
      '</div>'
    );
  }

  function render() {
    const filtered = applyFilters();
    const totalPages = Math.max(1, Math.ceil(filtered.length / PAGE_SIZE));
    state.page = Math.min(state.page, totalPages);
    const start = (state.page - 1) * PAGE_SIZE;
    const pageItems = filtered.slice(start, start + PAGE_SIZE);

    if (resultCountEl) {
      resultCountEl.textContent = filtered.length + (filtered.length === 1 ? ' product' : ' products');
    }

    if (gridEl) {
      gridEl.classList.toggle('is-list-view', state.view === 'list');
      gridEl.innerHTML = pageItems.length
        ? pageItems.map(productCardHTML).join('')
        : '<div class="no-results"><i class="fa-solid fa-snowflake"></i><h3>No products match your filters</h3><p>Try clearing a few filters or searching a different term.</p></div>';
    }

    renderPagination(totalPages);
    renderActiveFilters();
  }

  function renderPagination(totalPages) {
    if (!paginationEl) return;
    if (totalPages <= 1) {
      paginationEl.innerHTML = '';
      return;
    }

    let html = '<button type="button" data-page="' + (state.page - 1) + '" ' + (state.page === 1 ? 'disabled' : '') + ' aria-label="Previous page"><i class="fa-solid fa-chevron-left"></i></button>';
    for (let i = 1; i <= totalPages; i++) {
      html += '<button type="button" data-page="' + i + '" class="' + (i === state.page ? 'active' : '') + '">' + i + '</button>';
    }
    html += '<button type="button" data-page="' + (state.page + 1) + '" ' + (state.page === totalPages ? 'disabled' : '') + ' aria-label="Next page"><i class="fa-solid fa-chevron-right"></i></button>';
    paginationEl.innerHTML = html;
  }

  function renderActiveFilters() {
    if (!activeFiltersEl) return;
    const chips = [];

    state.colors.forEach((c) => chips.push({ label: c, type: 'color', value: c }));
    state.sizes.forEach((s) => chips.push({ label: 'Size ' + s, type: 'size', value: s }));
    if (state.maxPrice) chips.push({ label: 'Under ' + formatPKR(state.maxPrice), type: 'price', value: null });
    if (state.search) chips.push({ label: 'Search: "' + state.search + '"', type: 'search', value: null });

    activeFiltersEl.innerHTML = chips
      .map(
        (chip) =>
          '<span class="active-filter-chip" data-chip-type="' + chip.type + '" data-chip-value="' + (chip.value || '') + '">' +
          chip.label +
          '<button type="button" aria-label="Remove filter"><i class="fa-solid fa-xmark"></i></button></span>'
      )
      .join('');
  }

  /* --------------------------------------------------------------------
     EVENT WIRING
     -------------------------------------------------------------------- */

  // Grid delegated events: add to cart, wishlist toggle, quick view
  if (gridEl) {
    gridEl.addEventListener('click', (e) => {
      const wishlistBtn = e.target.closest('[data-wishlist-toggle]');
      const quickviewBtn = e.target.closest('[data-quickview]');
      const addToCartBtn = e.target.closest('.add-to-cart');

      if (wishlistBtn) {
        const id = wishlistBtn.dataset.wishlistToggle;
        const isNowActive = toggleWishlist(id);
        wishlistBtn.classList.toggle('is-active', isNowActive);
        wishlistBtn.setAttribute('aria-label', isNowActive ? 'Remove from wishlist' : 'Add to wishlist');
        const icon = wishlistBtn.querySelector('i');
        icon.classList.toggle('fa-solid', isNowActive);
        icon.classList.toggle('fa-regular', !isNowActive);
        if (window.SharlanToast) {
          window.SharlanToast.show(isNowActive ? 'Added to wishlist' : 'Removed from wishlist', isNowActive ? 'success' : 'info');
        }
        return;
      }

      if (quickviewBtn) {
        openQuickView(quickviewBtn.dataset.quickview, quickviewBtn);
        return;
      }

      if (addToCartBtn) {
        const card = addToCartBtn.closest('[data-product-id]');
        if (card && window.SharlanCart) {
          window.SharlanCart.add({
            id: card.dataset.productId,
            name: card.dataset.productName,
            price: Number(card.dataset.productPrice),
            image: card.dataset.productImage,
            size: null
          });
          if (window.SharlanToast) window.SharlanToast.show(card.dataset.productName + ' added to your bag', 'success');
        }
      }
    });
  }

  // Search input (debounced)
  const searchInput = document.getElementById('shop-search-input');
  let searchDebounce;
  if (searchInput) {
    searchInput.value = state.search;
    searchInput.addEventListener('input', () => {
      clearTimeout(searchDebounce);
      searchDebounce = setTimeout(() => {
        state.search = searchInput.value;
        state.page = 1;
        render();
      }, 250);
    });
  }

  // Sort select
  const sortSelect = document.getElementById('sort-select');
  if (sortSelect) {
    sortSelect.addEventListener('change', () => {
      state.sort = sortSelect.value;
      render();
    });
  }

  // Grid/list view toggle
  document.querySelectorAll('[data-view-toggle]').forEach((btn) => {
    btn.addEventListener('click', () => {
      state.view = btn.dataset.viewToggle;
      document.querySelectorAll('[data-view-toggle]').forEach((b) => b.classList.toggle('active', b === btn));
      render();
    });
  });

  // Color swatches
  document.querySelectorAll('[data-filter-color]').forEach((btn) => {
    btn.addEventListener('click', () => {
      const val = btn.dataset.filterColor;
      const active = btn.getAttribute('aria-pressed') === 'true';
      btn.setAttribute('aria-pressed', String(!active));
      if (active) state.colors.delete(val);
      else state.colors.add(val);
      state.page = 1;
      render();
    });
  });

  // Size chips
  document.querySelectorAll('[data-filter-size]').forEach((btn) => {
    btn.addEventListener('click', () => {
      const val = btn.dataset.filterSize;
      const active = btn.getAttribute('aria-pressed') === 'true';
      btn.setAttribute('aria-pressed', String(!active));
      if (active) state.sizes.delete(val);
      else state.sizes.add(val);
      state.page = 1;
      render();
    });
  });

  // Price range
  const priceSlider = document.getElementById('price-range-slider');
  const priceValueEl = document.getElementById('price-range-value');
  if (priceSlider) {
    priceSlider.addEventListener('input', () => {
      const val = Number(priceSlider.value);
      state.maxPrice = val >= Number(priceSlider.max) ? null : val;
      if (priceValueEl) priceValueEl.textContent = formatPKR(val) + (val >= Number(priceSlider.max) ? '+' : '');
      state.page = 1;
      render();
    });
  }

  // Category checkboxes (used on the all-products Shop view)
  document.querySelectorAll('[data-filter-category]').forEach((box) => {
    box.addEventListener('change', () => {
      const checked = Array.from(document.querySelectorAll('[data-filter-category]:checked')).map((b) => b.value);
      // Single-category model for simplicity: last checked wins, unchecking clears.
      state.category = checked.length ? checked[checked.length - 1] : null;
      state.page = 1;
      render();
    });
  });

  // Clear filters
  const clearFiltersBtn = document.getElementById('clear-filters-btn');
  if (clearFiltersBtn) {
    clearFiltersBtn.addEventListener('click', () => {
      state.colors.clear();
      state.sizes.clear();
      state.maxPrice = null;
      state.search = '';
      if (searchInput) searchInput.value = '';
      if (priceSlider) priceSlider.value = priceSlider.max;
      if (priceValueEl) priceValueEl.textContent = 'Any price';
      document.querySelectorAll('[aria-pressed="true"]').forEach((el) => el.setAttribute('aria-pressed', 'false'));
      document.querySelectorAll('[data-filter-category]').forEach((b) => (b.checked = false));
      state.page = 1;
      render();
    });
  }

  // Active filter chip removal (event delegation)
  if (activeFiltersEl) {
    activeFiltersEl.addEventListener('click', (e) => {
      const chip = e.target.closest('.active-filter-chip');
      if (!chip) return;
      const type = chip.dataset.chipType;
      const value = chip.dataset.chipValue;

      if (type === 'color') {
        state.colors.delete(value);
        const swatch = document.querySelector('[data-filter-color="' + value + '"]');
        if (swatch) swatch.setAttribute('aria-pressed', 'false');
      } else if (type === 'size') {
        state.sizes.delete(value);
        const chipEl = document.querySelector('[data-filter-size="' + value + '"]');
        if (chipEl) chipEl.setAttribute('aria-pressed', 'false');
      } else if (type === 'price') {
        state.maxPrice = null;
        if (priceSlider) priceSlider.value = priceSlider.max;
        if (priceValueEl) priceValueEl.textContent = 'Any price';
      } else if (type === 'search') {
        state.search = '';
        if (searchInput) searchInput.value = '';
      }

      state.page = 1;
      render();
    });
  }

  // Pagination click
  if (paginationEl) {
    paginationEl.addEventListener('click', (e) => {
      const btn = e.target.closest('button[data-page]');
      if (!btn || btn.disabled) return;
      state.page = Number(btn.dataset.page);
      render();
      window.scrollTo({ top: gridEl.offsetTop - 120, behavior: 'smooth' });
    });
  }

  // Mobile filter drawer
  const filtersSidebar = document.getElementById('filters-sidebar');
  const filtersOverlay = document.getElementById('filters-sidebar-overlay');
  const mobileFilterTrigger = document.getElementById('mobile-filter-trigger');
  const filtersCloseBtn = document.getElementById('filters-close-btn');

  function openFilters() {
    if (filtersSidebar) {
      filtersSidebar.classList.add('is-open');
      filtersSidebar.setAttribute('role', 'dialog');
      filtersSidebar.setAttribute('aria-modal', 'true');
      document.addEventListener('keydown', filtersTrapHandler);
      const firstControl = filtersSidebar.querySelector('button, input, [tabindex]');
      if (firstControl) firstControl.focus();
    }
    if (filtersOverlay) filtersOverlay.classList.add('is-open');
    document.body.style.overflow = 'hidden';
  }
  function closeFilters() {
    if (filtersSidebar) {
      filtersSidebar.classList.remove('is-open');
      filtersSidebar.removeAttribute('role');
      filtersSidebar.removeAttribute('aria-modal');
    }
    if (filtersOverlay) filtersOverlay.classList.remove('is-open');
    document.body.style.overflow = '';
    document.removeEventListener('keydown', filtersTrapHandler);
    if (mobileFilterTrigger) mobileFilterTrigger.focus();
  }
  const filtersTrapHandler = window.SharlanA11y ? window.SharlanA11y.trapFocus(filtersSidebar) : () => {};
  if (mobileFilterTrigger) mobileFilterTrigger.addEventListener('click', openFilters);
  if (filtersCloseBtn) filtersCloseBtn.addEventListener('click', closeFilters);
  if (filtersOverlay) filtersOverlay.addEventListener('click', closeFilters);

  // Collapsible filter groups
  document.querySelectorAll('.filter-group-title').forEach((title) => {
    title.addEventListener('click', () => {
      title.closest('.filter-group').classList.toggle('is-collapsed');
    });
  });

  /* --------------------------------------------------------------------
     QUICK VIEW MODAL
     -------------------------------------------------------------------- */
  const quickviewOverlay = document.getElementById('quickview-overlay');
  const quickviewContent = document.getElementById('quickview-content');
  const quickviewCloseBtn = document.getElementById('quickview-close');
  const quickviewTrapHandler = window.SharlanA11y ? window.SharlanA11y.trapFocus(quickviewOverlay) : () => {};
  let quickviewTriggerEl = null;

  function openQuickView(id, triggerEl) {
    const p = ALL_PRODUCTS.find((prod) => prod.id === id);
    if (!p || !quickviewOverlay || !quickviewContent) return;
    quickviewTriggerEl = triggerEl || null;

    const sizesHTML = p.sizes
      ? '<div class="option-group"><span class="option-group-label">Size</span><div class="size-chip-list">' +
        p.sizes.map((s) => '<span class="size-chip">' + s + '</span>').join('') +
        '</div></div>'
      : '';
    const colorsHTML =
      '<div class="option-group"><span class="option-group-label">Color</span><div class="color-swatch-list">' +
      p.colors.map((c) => '<span class="color-swatch" style="background:' + c.hex + '" title="' + c.name + '"></span>').join('') +
      '</div></div>';

    quickviewContent.innerHTML =
      '<div class="quickview-media"><img src="' + p.images[0] + '" alt="' + p.name + '"></div>' +
      '<div class="quickview-info">' +
      '<span class="product-category">' + p.category + '</span>' +
      '<h3>' + p.name + '</h3>' +
      '<div class="price-row"><span class="price">' + formatPKR(p.price) + '</span>' +
      (p.originalPrice ? '<span class="price-original">' + formatPKR(p.originalPrice) + '</span>' : '') +
      '</div>' +
      '<p class="desc">' + p.description + '</p>' +
      colorsHTML +
      sizesHTML +
      '<div class="quickview-actions">' +
      '<button type="button" class="btn" data-quickview-add="' + p.id + '"><span>Add to Cart</span></button>' +
      '<a href="product.html?id=' + p.id + '" class="btn btn-dark-surface" style="background:var(--color-white);color:var(--color-charcoal);"><span>Full Details</span></a>' +
      '</div>' +
      '</div>';

    quickviewOverlay.classList.add('is-open');
    document.body.style.overflow = 'hidden';
    document.addEventListener('keydown', quickviewTrapHandler);
    quickviewCloseBtn.focus();

    const addBtn = quickviewContent.querySelector('[data-quickview-add]');
    if (addBtn) {
      addBtn.addEventListener('click', () => {
        if (window.SharlanCart) {
          window.SharlanCart.add({ id: p.id, name: p.name, price: p.price, image: p.images[0], size: null });
        }
        if (window.SharlanToast) window.SharlanToast.show(p.name + ' added to your bag', 'success');
        closeQuickView();
      });
    }
  }

  function closeQuickView() {
    if (quickviewOverlay) quickviewOverlay.classList.remove('is-open');
    document.body.style.overflow = '';
    document.removeEventListener('keydown', quickviewTrapHandler);
    if (quickviewTriggerEl) quickviewTriggerEl.focus();
  }

  if (quickviewCloseBtn) quickviewCloseBtn.addEventListener('click', closeQuickView);
  if (quickviewOverlay) {
    quickviewOverlay.addEventListener('click', (e) => {
      if (e.target === quickviewOverlay) closeQuickView();
    });
  }
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && quickviewOverlay && quickviewOverlay.classList.contains('is-open')) {
      closeQuickView();
    }
  });

  /* --------------------------------------------------------------------
     INITIAL RENDER
     -------------------------------------------------------------------- */
  document.querySelectorAll('[data-filter-category]').forEach((box) => {
    if (box.value === state.category) box.checked = true;
  });

  render();
})();
