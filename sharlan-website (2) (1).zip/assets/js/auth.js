/* ==========================================================================
   SHARLAN — AUTH.JS
   Form handling for Login, Register, and Forgot Password. Talks to
   auth-store.js (a localStorage demo — see that file's header comment).
   Detects which page it's on via the presence of each form's id, so one
   file can serve all three pages without duplicating boilerplate.
   ========================================================================== */

(function () {
  'use strict';

  if (window.SharlanAuth && window.SharlanAuth.seedDemoIfEmpty) {
    window.SharlanAuth.seedDemoIfEmpty();
  }

  function showFieldError(input, show) {
    const group = input.closest('.form-group');
    if (group) group.classList.toggle('has-error', show);
  }

  function setCustomError(input, message) {
    const group = input.closest('.form-group');
    const errEl = group ? group.querySelector('.form-error-text') : null;
    if (errEl && message) errEl.textContent = message;
  }

  /* ---- Password visibility toggle (shared across all three forms) ---- */
  document.querySelectorAll('.password-toggle').forEach((btn) => {
    btn.addEventListener('click', () => {
      const input = btn.previousElementSibling;
      if (!input) return;
      const isPassword = input.type === 'password';
      input.type = isPassword ? 'text' : 'password';
      btn.querySelector('i').className = isPassword ? 'fa-regular fa-eye-slash' : 'fa-regular fa-eye';
    });
  });

  /* --------------------------------------------------------------------
     LOGIN
     -------------------------------------------------------------------- */
  const loginForm = document.getElementById('login-form');
  if (loginForm) {
    loginForm.addEventListener('submit', (e) => {
      e.preventDefault();
      const emailInput = document.getElementById('login-email');
      const passwordInput = document.getElementById('login-password');
      const email = emailInput.value.trim();
      const password = passwordInput.value;

      const emailValid = emailInput.checkValidity() && email;
      showFieldError(emailInput, !emailValid);
      if (!emailValid) return;

      const result = window.SharlanAuth ? window.SharlanAuth.login(email, password) : { success: false, error: 'Auth unavailable' };

      if (!result.success) {
        showFieldError(passwordInput, true);
        setCustomError(passwordInput, result.error);
        if (window.SharlanToast) window.SharlanToast.show(result.error, 'error');
        return;
      }

      if (window.SharlanToast) window.SharlanToast.show('Welcome back!', 'success');
      setTimeout(() => {
        window.location.href = 'account.html';
      }, 500);
    });
  }

  /* --------------------------------------------------------------------
     REGISTER
     -------------------------------------------------------------------- */
  const registerForm = document.getElementById('register-form');
  if (registerForm) {
    registerForm.addEventListener('submit', (e) => {
      e.preventDefault();

      const nameInput = document.getElementById('register-name');
      const emailInput = document.getElementById('register-email');
      const phoneInput = document.getElementById('register-phone');
      const passwordInput = document.getElementById('register-password');
      const confirmInput = document.getElementById('register-confirm');
      const termsInput = document.getElementById('register-terms');

      let valid = true;

      const nameOk = nameInput.value.trim().length > 1;
      showFieldError(nameInput, !nameOk);
      valid = valid && nameOk;

      const emailOk = emailInput.checkValidity() && emailInput.value.trim();
      showFieldError(emailInput, !emailOk);
      valid = valid && emailOk;

      const passwordOk = passwordInput.value.length >= 8;
      showFieldError(passwordInput, !passwordOk);
      setCustomError(passwordInput, 'Password must be at least 8 characters.');
      valid = valid && passwordOk;

      const confirmOk = confirmInput.value === passwordInput.value && passwordInput.value.length > 0;
      showFieldError(confirmInput, !confirmOk);
      setCustomError(confirmInput, 'Passwords do not match.');
      valid = valid && confirmOk;

      if (!termsInput.checked) {
        if (window.SharlanToast) window.SharlanToast.show('Please accept the Terms & Conditions to continue.', 'error');
        valid = false;
      }

      if (!valid) return;

      const result = window.SharlanAuth
        ? window.SharlanAuth.register({
            name: nameInput.value.trim(),
            email: emailInput.value.trim(),
            phone: phoneInput.value.trim(),
            password: passwordInput.value
          })
        : { success: false, error: 'Auth unavailable' };

      if (!result.success) {
        showFieldError(emailInput, true);
        setCustomError(emailInput, result.error);
        if (window.SharlanToast) window.SharlanToast.show(result.error, 'error');
        return;
      }

      if (window.SharlanToast) window.SharlanToast.show('Account created — welcome to SHARLAN!', 'success');
      setTimeout(() => {
        window.location.href = 'account.html';
      }, 500);
    });
  }

  /* --------------------------------------------------------------------
     FORGOT PASSWORD
     -------------------------------------------------------------------- */
  const forgotForm = document.getElementById('forgot-password-form');
  if (forgotForm) {
    forgotForm.addEventListener('submit', (e) => {
      e.preventDefault();
      const emailInput = document.getElementById('forgot-email');
      const emailValid = emailInput.checkValidity() && emailInput.value.trim();
      showFieldError(emailInput, !emailValid);
      if (!emailValid) return;

      // No real email-sending service yet — this simulates the UX so the
      // flow can be reviewed end-to-end; wiring an actual reset email is
      // backend work for a later phase.
      const successNote = document.getElementById('forgot-success-note');
      const formFields = document.getElementById('forgot-form-fields');
      if (successNote) successNote.classList.add('is-visible');
      if (formFields) formFields.style.display = 'none';
    });
  }
})();
