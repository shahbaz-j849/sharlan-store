/* ==========================================================================
   SHARLAN — ADDRESSES-STORE.JS
   Saved delivery addresses, shared between the Account dashboard (manage)
   and Checkout (select at delivery step). localStorage-backed demo data
   layer, same caveat as auth-store.js / orders-store.js.
   ========================================================================== */

(function () {
  'use strict';

  const KEY = 'sharlan_addresses_v1';

  function getAll() {
    try {
      return JSON.parse(localStorage.getItem(KEY)) || [];
    } catch (e) {
      return [];
    }
  }

  function saveAll(list) {
    try {
      localStorage.setItem(KEY, JSON.stringify(list));
    } catch (e) {
      /* no-op */
    }
  }

  function add(address) {
    const list = getAll();
    const entry = Object.assign({ id: 'addr-' + Date.now() }, address);
    if (entry.isDefault) {
      list.forEach((a) => (a.isDefault = false));
    }
    list.push(entry);
    saveAll(list);
    return entry;
  }

  function remove(id) {
    saveAll(getAll().filter((a) => a.id !== id));
  }

  function getDefault() {
    const list = getAll();
    return list.find((a) => a.isDefault) || list[0] || null;
  }

  window.SharlanAddresses = { getAll: getAll, add: add, remove: remove, getDefault: getDefault };
})();
