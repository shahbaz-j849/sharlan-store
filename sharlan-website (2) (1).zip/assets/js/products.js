/* ==========================================================================
   SHARLAN — PRODUCT CATALOG
   Single source of truth for every product. Shop, category, and product
   detail pages all read from window.SHARLAN_PRODUCTS instead of hardcoding
   items — so adding a new product or category later means editing this
   one file, not every page.

   Field reference:
   id            unique SKU string
   name          display name
   category      'jackets' | 'sneakers' | 'jeans' | 'watches'
   gender        'men' | 'women' | 'unisex'
   price         current price in PKR (number)
   originalPrice optional — set when the item is on sale
   isNew         true if it should appear in "New Arrivals"
   isBestSeller  true if it should appear in "Best Sellers"
   collections   array of collection tags, e.g. ['winter']
   images        array of image URLs — [0] primary, [1] hover/alt, [2..] gallery
   sizes         array of size labels (null for one-size items like most watches)
   colors        array of { name, hex }
   material      short material description
   stock         'in_stock' | 'low_stock' | 'out_of_stock'
   rating        average rating out of 5
   reviewCount   number of reviews
   description   short product description
   ========================================================================== */

window.SHARLAN_PRODUCTS = [
  {
    id: 'sku-001',
    name: 'Arctic Puffer Alpha',
    category: 'jackets',
    gender: 'men',
    price: 18900,
    originalPrice: null,
    isNew: true,
    isBestSeller: false,
    collections: ['winter'],
    images: [
      'https://images.unsplash.com/photo-1544022613-e87ea74a77bf?auto=format&fit=crop&w=700&q=80',
      'https://images.unsplash.com/photo-1520975954732-35dd22299614?auto=format&fit=crop&w=700&q=80',
      'https://images.unsplash.com/photo-1591047139829-d91aecb6caea?auto=format&fit=crop&w=700&q=80',
      'https://images.unsplash.com/photo-1551028719-00167b16eac5?auto=format&fit=crop&w=700&q=80'
    ],
    sizes: ['S', 'M', 'L', 'XL', 'XXL'],
    colors: [{ name: 'Charcoal', hex: '#121212' }, { name: 'Ice Grey', hex: '#c7c9cc' }],
    material: 'Recycled nylon shell, 650-fill down insulation',
    stock: 'in_stock',
    rating: 4.8,
    reviewCount: 96,
    description: 'Our heaviest-duty puffer, engineered for sub-zero mornings without the bulk. A storm-sealed zip and adjustable hood keep the cold out while the tapered cut keeps the silhouette sharp.'
  },
  {
    id: 'sku-004',
    name: 'Midnight Bomber',
    category: 'jackets',
    gender: 'men',
    price: 14500,
    originalPrice: 18000,
    isNew: false,
    isBestSeller: true,
    collections: ['winter'],
    images: [
      'https://images.unsplash.com/photo-1591047139829-d91aecb6caea?auto=format&fit=crop&w=700&q=80',
      'https://images.unsplash.com/photo-1551028719-00167b16eac5?auto=format&fit=crop&w=700&q=80',
      'https://images.unsplash.com/photo-1544022613-e87ea74a77bf?auto=format&fit=crop&w=700&q=80'
    ],
    sizes: ['S', 'M', 'L', 'XL'],
    colors: [{ name: 'Midnight Black', hex: '#121212' }, { name: 'Olive', hex: '#5f6244' }],
    material: 'Brushed cotton twill, quilted lining',
    stock: 'in_stock',
    rating: 4.6,
    reviewCount: 142,
    description: 'A modern take on the classic bomber — quilted lining for warmth, ribbed cuffs for a clean finish, and a fit that layers well over hoodies.'
  },
  {
    id: 'sku-006',
    name: 'Heavy Cotton Overshirt',
    category: 'jackets',
    gender: 'men',
    price: 7500,
    originalPrice: null,
    isNew: true,
    isBestSeller: false,
    collections: [],
    images: [
      'https://images.unsplash.com/photo-1516259762381-22954d7d3ad2?auto=format&fit=crop&w=700&q=80',
      'https://images.unsplash.com/photo-1511405946472-a37e3b5ccd47?auto=format&fit=crop&w=700&q=80'
    ],
    sizes: ['S', 'M', 'L', 'XL'],
    colors: [{ name: 'Stone', hex: '#c7c9cc' }, { name: 'Brown', hex: '#5a4436' }],
    material: '100% heavyweight cotton',
    stock: 'low_stock',
    rating: 4.4,
    reviewCount: 58,
    description: 'A between-seasons layer that works as a light jacket or an open shirt over a tee. Heavyweight cotton holds its shape wash after wash.'
  },
  {
    id: 'sku-011',
    name: 'Frost Line Parka',
    category: 'jackets',
    gender: 'women',
    price: 21500,
    originalPrice: null,
    isNew: true,
    isBestSeller: true,
    collections: ['winter'],
    images: [
      'https://images.unsplash.com/photo-1548624313-0396c75f2f0c?auto=format&fit=crop&w=700&q=80',
      'https://images.unsplash.com/photo-1548883354-94bcfe321cbb?auto=format&fit=crop&w=700&q=80'
    ],
    sizes: ['XS', 'S', 'M', 'L'],
    colors: [{ name: 'Charcoal', hex: '#121212' }, { name: 'Cream', hex: '#f4f6f8' }],
    material: 'Water-resistant shell, faux-fur trim hood',
    stock: 'in_stock',
    rating: 4.9,
    reviewCount: 74,
    description: 'A longline parka built for Pakistan\'s coldest mornings — sealed seams, an insulated hood, and a fit that layers cleanly over knitwear.'
  },
  {
    id: 'sku-002',
    name: 'Neon Frost Low-Tops',
    category: 'sneakers',
    gender: 'unisex',
    price: 12000,
    originalPrice: null,
    isNew: true,
    isBestSeller: false,
    collections: [],
    images: [
      'https://images.unsplash.com/photo-1606107557195-0e29a4b5b4aa?auto=format&fit=crop&w=700&q=80',
      'https://images.unsplash.com/photo-1608231387042-66d1773070a5?auto=format&fit=crop&w=700&q=80'
    ],
    sizes: ['UK 6', 'UK 7', 'UK 8', 'UK 9', 'UK 10', 'UK 11'],
    colors: [{ name: 'White/Blue', hex: '#00d4ff' }, { name: 'Triple Black', hex: '#121212' }],
    material: 'Knit upper, EVA cushioned sole',
    stock: 'in_stock',
    rating: 4.5,
    reviewCount: 203,
    description: 'Lightweight low-tops with a breathable knit upper and a cushioned sole built for all-day wear, on campus or on the street.'
  },
  {
    id: 'sku-005',
    name: 'Titanium Runners',
    category: 'sneakers',
    gender: 'men',
    price: 16000,
    originalPrice: null,
    isNew: true,
    isBestSeller: true,
    collections: [],
    images: [
      'https://images.unsplash.com/photo-1491553895911-0055eca6402d?auto=format&fit=crop&w=700&q=80',
      'https://images.unsplash.com/photo-1560769629-975ec94e6a86?auto=format&fit=crop&w=700&q=80'
    ],
    sizes: ['UK 7', 'UK 8', 'UK 9', 'UK 10', 'UK 11'],
    colors: [{ name: 'Grey', hex: '#7a7a7e' }, { name: 'Black', hex: '#121212' }],
    material: 'Mesh + synthetic overlay, rubber outsole',
    stock: 'in_stock',
    rating: 4.7,
    reviewCount: 168,
    description: 'Our best-selling runner — durable rubber outsole, responsive cushioning, and a silhouette that works equally well with denim or joggers.'
  },
  {
    id: 'sku-012',
    name: 'Blizzard High-Tops',
    category: 'sneakers',
    gender: 'women',
    price: 13500,
    originalPrice: 15500,
    isNew: false,
    isBestSeller: true,
    collections: ['winter'],
    images: [
      'https://images.unsplash.com/photo-1595950653106-6c9ebd614d3a?auto=format&fit=crop&w=700&q=80',
      'https://images.unsplash.com/photo-1600185365483-26d7a4cc7519?auto=format&fit=crop&w=700&q=80'
    ],
    sizes: ['UK 4', 'UK 5', 'UK 6', 'UK 7', 'UK 8'],
    colors: [{ name: 'Ice White', hex: '#f4f6f8' }, { name: 'Charcoal', hex: '#121212' }],
    material: 'Water-resistant canvas, fleece collar',
    stock: 'low_stock',
    rating: 4.6,
    reviewCount: 87,
    description: "A fleece-lined high-top built to handle wet pavements and cold mornings without giving up the clean lines you'd expect from a low-top."
  },
  {
    id: 'sku-003',
    name: 'Charcoal Slim Denim',
    category: 'jeans',
    gender: 'men',
    price: 8500,
    originalPrice: null,
    isNew: false,
    isBestSeller: true,
    collections: [],
    images: [
      'https://images.unsplash.com/photo-1542272604-787c3835535d?auto=format&fit=crop&w=700&q=80',
      'https://images.unsplash.com/photo-1541099649105-f69ad21f3246?auto=format&fit=crop&w=700&q=80'
    ],
    sizes: ['28', '30', '32', '34', '36', '38'],
    colors: [{ name: 'Charcoal', hex: '#121212' }, { name: 'Mid Wash', hex: '#7a7a7e' }],
    material: '98% cotton, 2% elastane',
    stock: 'in_stock',
    rating: 4.5,
    reviewCount: 231,
    description: 'A slim, tapered cut with just enough stretch to move with you. Our most-repurchased item for a reason.'
  },
  {
    id: 'sku-007',
    name: 'Straight Fit Indigo',
    category: 'jeans',
    gender: 'men',
    price: 7900,
    originalPrice: null,
    isNew: true,
    isBestSeller: false,
    collections: [],
    images: [
      'https://images.unsplash.com/photo-1541099649105-f69ad21f3246?auto=format&fit=crop&w=700&q=80',
      'https://images.unsplash.com/photo-1542272604-787c3835535d?auto=format&fit=crop&w=700&q=80'
    ],
    sizes: ['30', '32', '34', '36'],
    colors: [{ name: 'Indigo', hex: '#2a3550' }],
    material: '100% cotton denim',
    stock: 'in_stock',
    rating: 4.3,
    reviewCount: 44,
    description: 'A straight-leg cut in classic indigo denim — built heavier than most for a break-in that gets better with wear.'
  },
  {
    id: 'sku-013',
    name: 'High-Rise Ice Wash',
    category: 'jeans',
    gender: 'women',
    price: 8900,
    originalPrice: null,
    isNew: true,
    isBestSeller: false,
    collections: ['winter'],
    images: [
      'https://images.unsplash.com/photo-1541099649105-f69ad21f3246?auto=format&fit=crop&w=700&q=80',
      'https://images.unsplash.com/photo-1548883354-94bcfe321cbb?auto=format&fit=crop&w=700&q=80'
    ],
    sizes: ['26', '28', '30', '32', '34'],
    colors: [{ name: 'Ice Wash', hex: '#c7c9cc' }],
    material: '99% cotton, 1% elastane',
    stock: 'in_stock',
    rating: 4.7,
    reviewCount: 66,
    description: 'A high-rise straight leg with a lightly faded wash — pairs cleanly with an oversized jacket for the full winter silhouette.'
  },
  {
    id: 'sku-008',
    name: 'Steel Chrono',
    category: 'watches',
    gender: 'men',
    price: 22000,
    originalPrice: null,
    isNew: false,
    isBestSeller: true,
    collections: [],
    images: [
      'https://images.unsplash.com/photo-1524805444758-089113d48a6d?auto=format&fit=crop&w=700&q=80',
      'https://images.unsplash.com/photo-1522312346375-d1a52e2b99b3?auto=format&fit=crop&w=700&q=80'
    ],
    sizes: null,
    colors: [{ name: 'Steel', hex: '#c7c9cc' }, { name: 'Gunmetal', hex: '#3a3a3d' }],
    material: 'Stainless steel case, sapphire-coated crystal',
    stock: 'in_stock',
    rating: 4.8,
    reviewCount: 112,
    description: 'A chronograph face in brushed stainless steel — water-resistant to 50m and backed by a 2-year movement warranty.'
  },
  {
    id: 'sku-009',
    name: 'Leather Strap Classic',
    category: 'watches',
    gender: 'men',
    price: 15500,
    originalPrice: 19000,
    isNew: false,
    isBestSeller: false,
    collections: [],
    images: [
      'https://images.unsplash.com/photo-1508057198894-247b23fe5ade?auto=format&fit=crop&w=700&q=80',
      'https://images.unsplash.com/photo-1524805444758-089113d48a6d?auto=format&fit=crop&w=700&q=80'
    ],
    sizes: null,
    colors: [{ name: 'Brown Leather', hex: '#5a4436' }, { name: 'Black Leather', hex: '#121212' }],
    material: 'Genuine leather strap, stainless steel case',
    stock: 'in_stock',
    rating: 4.6,
    reviewCount: 78,
    description: 'A minimal dial paired with a genuine leather strap — dresses up or down depending on what you put it with.'
  },
  {
    id: 'sku-014',
    name: 'Ice Face Minimal',
    category: 'watches',
    gender: 'women',
    price: 13900,
    originalPrice: null,
    isNew: true,
    isBestSeller: false,
    collections: ['winter'],
    images: [
      'https://images.unsplash.com/photo-1509048191080-d2984bad6ae5?auto=format&fit=crop&w=700&q=80',
      'https://images.unsplash.com/photo-1524805444758-089113d48a6d?auto=format&fit=crop&w=700&q=80'
    ],
    sizes: null,
    colors: [{ name: 'Rose Gold', hex: '#b76e79' }, { name: 'Silver', hex: '#c7c9cc' }],
    material: 'Stainless steel mesh band',
    stock: 'low_stock',
    rating: 4.9,
    reviewCount: 51,
    description: 'A clean, minimal dial on a fine stainless mesh band — light enough for daily wear, sharp enough for anything you pair it with.'
  }
];
