/* ==========================================================================
   SHARLAN — UI.JS
   Reusable UI helpers: toast notification system (replaces browser alert()),
   scroll-reveal animations, back-to-top button, and homepage product tabs.
   ========================================================================== */

(function () {
  'use strict';

  /* --------------------------------------------------------------------
     TOAST NOTIFICATIONS
     Usage: window.SharlanToast.show('Message', 'success' | 'error' | 'info')
     -------------------------------------------------------------------- */
  const toastStack = document.querySelector('.toast-stack');

  const toastIcons = {
    success: 'fa-solid fa-circle-check',
    error: 'fa-solid fa-circle-exclamation',
    info: 'fa-solid fa-snowflake',
  };

  function showToast(message, type) {
    if (!toastStack) return;
    type = type || 'info';

    const toast = document.createElement('div');
    toast.className = 'toast toast-' + type;
    toast.setAttribute('role', 'status');
    toast.setAttribute('aria-live', 'polite');
    toast.innerHTML =
      '<i class="' + (toastIcons[type] || toastIcons.info) + '"></i><span>' + message + '</span>';

    toastStack.appendChild(toast);
    requestAnimationFrame(() => toast.classList.add('is-visible'));

    setTimeout(() => {
      toast.classList.remove('is-visible');
      setTimeout(() => toast.remove(), 350);
    }, 3200);
  }

  window.SharlanToast = { show: showToast };

  /* --------------------------------------------------------------------
     SCROLL REVEAL
     Any element with class="reveal" fades/slides in once it enters
     the viewport. Respects prefers-reduced-motion via CSS.
     -------------------------------------------------------------------- */
  const revealEls = document.querySelectorAll('.reveal');

  if ('IntersectionObserver' in window && revealEls.length) {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add('is-visible');
            observer.unobserve(entry.target);
          }
        });
      },
      { threshold: 0.12, rootMargin: '0px 0px -40px 0px' }
    );

    revealEls.forEach((el, i) => {
      el.style.transitionDelay = Math.min(i % 4, 3) * 80 + 'ms';
      observer.observe(el);
    });
  } else {
    revealEls.forEach((el) => el.classList.add('is-visible'));
  }

  /* --------------------------------------------------------------------
     BACK TO TOP
     -------------------------------------------------------------------- */
  const backToTopBtn = document.querySelector('.back-to-top');

  if (backToTopBtn) {
    window.addEventListener(
      'scroll',
      () => {
        backToTopBtn.classList.toggle('is-visible', window.scrollY > 700);
      },
      { passive: true }
    );

    backToTopBtn.addEventListener('click', () => {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    });
  }

  /* --------------------------------------------------------------------
     HOMEPAGE PRODUCT TABS (New Arrivals / Best Sellers)
     -------------------------------------------------------------------- */
  const tabButtons = document.querySelectorAll('[data-tab-filter]');
  const productCards = document.querySelectorAll('[data-product-category]');

  function filterProducts(category) {
    tabButtons.forEach((btn) => {
      btn.classList.toggle('active', btn.dataset.tabFilter === category);
      btn.setAttribute('aria-selected', btn.dataset.tabFilter === category ? 'true' : 'false');
    });

    productCards.forEach((card) => {
      const match = card.dataset.productCategory === category;
      card.style.display = match ? '' : 'none';
    });
  }

  tabButtons.forEach((btn) => {
    btn.addEventListener('click', () => filterProducts(btn.dataset.tabFilter));
  });

  /* Apply the default filter on load so the grid matches whichever tab
     is marked active in the HTML (previously the grid showed every
     product on first load regardless of the active tab). */
  const initialTab = document.querySelector('[data-tab-filter].active');
  if (initialTab) filterProducts(initialTab.dataset.tabFilter);

  /* --------------------------------------------------------------------
     WISHLIST QUICK-ACTION
     Persisted to the same localStorage key the Shop, Product, and
     Wishlist pages read from, so a save here shows up everywhere.
     -------------------------------------------------------------------- */
  const WISHLIST_KEY = 'sharlan_wishlist_v1';

  function getWishlistIds() {
    try {
      return JSON.parse(localStorage.getItem(WISHLIST_KEY)) || [];
    } catch (e) {
      return [];
    }
  }

  function toggleWishlistId(id) {
    if (!id) return null;
    let list = getWishlistIds();
    const idx = list.indexOf(id);
    if (idx > -1) list.splice(idx, 1);
    else list.push(id);
    try {
      localStorage.setItem(WISHLIST_KEY, JSON.stringify(list));
    } catch (e) {
      /* localStorage unavailable — toggle still works for this view */
    }
    return list.includes(id);
  }

  // Pre-mark homepage wishlist buttons that are already saved
  const savedWishlist = getWishlistIds();
  document.querySelectorAll('[data-wishlist-toggle]').forEach((btn) => {
    const card = btn.closest('[data-product-id]');
    const id = card ? card.dataset.productId : null;
    if (id && savedWishlist.includes(id)) {
      btn.classList.add('is-active');
      btn.setAttribute('aria-label', 'Remove from wishlist');
      const icon = btn.querySelector('i');
      if (icon) {
        icon.classList.remove('fa-regular');
        icon.classList.add('fa-solid');
      }
    }

    btn.addEventListener('click', () => {
      const active = id ? toggleWishlistId(id) : btn.classList.toggle('is-active');
      if (id) btn.classList.toggle('is-active', active);
      btn.setAttribute('aria-label', active ? 'Remove from wishlist' : 'Add to wishlist');
      const icon = btn.querySelector('i');
      if (icon) {
        icon.classList.toggle('fa-regular', !active);
        icon.classList.toggle('fa-solid', active);
      }
      showToast(active ? 'Added to wishlist' : 'Removed from wishlist', active ? 'success' : 'info');
    });
  });

  /* --------------------------------------------------------------------
     PLACEHOLDER LINKS
     Pages like Shop, policy pages, and social profiles don't exist yet
     (they arrive in later phases). Rather than silently jumping to the
     top of the page on click, tell the person what's going on.
     Real in-page anchors (e.g. href="#hero") are untouched — this only
     targets bare "#" hrefs.
     -------------------------------------------------------------------- */
  document.querySelectorAll('a[href="#"]').forEach((link) => {
    link.addEventListener('click', (e) => {
      e.preventDefault();
      showToast("This page isn't live yet — it's on the way in a later phase.", 'info');
    });
  });

  /* ---- Quick view — sends to the full product detail page ---- */
  document.querySelectorAll('.quick-action-btn[aria-label="Quick view"]').forEach((btn) => {
    btn.addEventListener('click', () => {
      const card = btn.closest('[data-product-id]');
      if (card && card.dataset.productId) {
        window.location.href = 'pages/product.html?id=' + card.dataset.productId;
      } else {
        showToast('Quick view is available from the Shop page.', 'info');
      }
    });
  });

  /* --------------------------------------------------------------------
     SEARCH INPUT — sends the query to the Shop page, which reads the
     same "q" URL param shop.js already filters on. (Previously this
     just showed a "not available yet" toast, which became stale once
     the Shop catalog and its search box shipped in Phase 2.)
     -------------------------------------------------------------------- */
  const siteSearchInput = document.getElementById('site-search');
  if (siteSearchInput) {
    siteSearchInput.addEventListener('keydown', (e) => {
      if (e.key !== 'Enter') return;
      e.preventDefault();
      const q = siteSearchInput.value.trim();
      const onPagesDir = window.location.pathname.includes('/pages/');
      const shopUrl = (onPagesDir ? 'shop.html' : 'pages/shop.html') + (q ? '?q=' + encodeURIComponent(q) : '');
      window.location.href = shopUrl;
    });
  }

  /* --------------------------------------------------------------------
     NEWSLETTER FORM — inline validation + toast (no browser alert)
     -------------------------------------------------------------------- */
  const newsletterForm = document.getElementById('newsletter-form');

  if (newsletterForm) {
    newsletterForm.addEventListener('submit', (e) => {
      e.preventDefault();
      const field = newsletterForm.querySelector('.form-field');
      const input = newsletterForm.querySelector('input[type="email"]');
      const isValid = input.checkValidity();

      field.classList.toggle('has-error', !isValid);

      if (!isValid) {
        input.focus();
        return;
      }

      showToast("You're in! Check your inbox for your 10% code.", 'success');
      newsletterForm.reset();
      field.classList.remove('has-error');
    });
  }
})();
