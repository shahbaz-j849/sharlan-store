/* ==========================================================================
   SHARLAN — ORDERS-STORE.JS
   A tiny localStorage-backed "orders" data layer shared by checkout.js
   (creates orders), account.js (lists a signed-in user's orders), and
   track-order.js (looks an order up by number). There's no real backend
   yet — this is a demo data layer only, clearly documented as such.
   ========================================================================== */

(function () {
  'use strict';

  const ORDERS_KEY = 'sharlan_orders_v1';

  function getAllOrders() {
    try {
      return JSON.parse(localStorage.getItem(ORDERS_KEY)) || [];
    } catch (e) {
      return [];
    }
  }

  function saveAllOrders(orders) {
    try {
      localStorage.setItem(ORDERS_KEY, JSON.stringify(orders));
    } catch (e) {
      /* localStorage unavailable — order still returns for this session */
    }
  }

  function generateOrderNumber() {
    const rand = Math.floor(100000 + Math.random() * 900000);
    return 'SHR-' + rand;
  }

  function addOrder(orderData) {
    const orders = getAllOrders();
    const order = Object.assign(
      {
        id: generateOrderNumber(),
        date: new Date().toISOString(),
        status: 'processing'
      },
      orderData
    );
    orders.unshift(order);
    saveAllOrders(orders);
    return order;
  }

  function getOrderById(id) {
    return getAllOrders().find((o) => o.id.toLowerCase() === String(id).toLowerCase()) || null;
  }

  /* Seed a couple of demo orders on first load so Account > My Orders and
     Track Order have something real to show before anyone has checked
     out. Only runs once — if the key already exists (even as an empty
     array from real use), it's left alone. */
  function seedDemoOrdersIfEmpty() {
    try {
      if (localStorage.getItem(ORDERS_KEY) !== null) return;
    } catch (e) {
      return;
    }

    const demoOrders = [
      {
        id: 'SHR-482913',
        date: new Date(Date.now() - 6 * 24 * 3600 * 1000).toISOString(),
        status: 'delivered',
        items: [{ id: 'sku-003', name: 'Charcoal Slim Denim', price: 8500, qty: 1, image: 'https://images.unsplash.com/photo-1542272604-787c3835535d?auto=format&fit=crop&w=200&q=60', size: '32' }],
        subtotal: 8500,
        shipping: 0,
        discount: 0,
        total: 8500,
        billing: { firstName: 'Demo', lastName: 'Customer', email: 'demo@sharlan.pk', phone: '+92 300 1234567' },
        shippingAddress: { address: 'House 12, Street 4, DHA Phase 5', city: 'Lahore', postalCode: '54000' },
        deliveryMethod: 'standard',
        paymentMethod: 'cod',
        notes: ''
      },
      {
        id: 'SHR-217705',
        date: new Date(Date.now() - 1 * 24 * 3600 * 1000).toISOString(),
        status: 'shipped',
        items: [
          { id: 'sku-001', name: 'Arctic Puffer Alpha', price: 18900, qty: 1, image: 'https://images.unsplash.com/photo-1544022613-e87ea74a77bf?auto=format&fit=crop&w=200&q=60', size: 'L' },
          { id: 'sku-005', name: 'Titanium Runners', price: 16000, qty: 1, image: 'https://images.unsplash.com/photo-1491553895911-0055eca6402d?auto=format&fit=crop&w=200&q=60', size: 'UK 9' }
        ],
        subtotal: 34900,
        shipping: 0,
        discount: 0,
        total: 34900,
        billing: { firstName: 'Demo', lastName: 'Customer', email: 'demo@sharlan.pk', phone: '+92 300 1234567' },
        shippingAddress: { address: 'Flat 3B, Clifton Block 2', city: 'Karachi', postalCode: '75600' },
        deliveryMethod: 'express',
        paymentMethod: 'jazzcash',
        notes: ''
      }
    ];

    saveAllOrders(demoOrders);
  }

  window.SharlanOrders = {
    getAll: getAllOrders,
    add: addOrder,
    getById: getOrderById,
    seedDemoIfEmpty: seedDemoOrdersIfEmpty
  };
})();
