/* ==========================================================================
   SHARLAN — NAVIGATION.JS
   Handles: sticky nav background on scroll, hamburger + mobile slide-out
   panel, and the full-screen search overlay. Fully keyboard accessible.
   ========================================================================== */

(function () {
  'use strict';

  /* ---- Shared focus-trap helper, reused by app.js for the cart drawer ----
     Keeps Tab/Shift+Tab cycling inside an open dialog-like panel instead
     of escaping to the page behind it. */
  function trapFocus(container) {
    return function handleTrap(e) {
      if (e.key !== 'Tab' || !container) return;
      const focusable = container.querySelectorAll(
        'a[href], button:not([disabled]), input:not([disabled]), [tabindex]:not([tabindex="-1"])'
      );
      if (!focusable.length) return;
      const first = focusable[0];
      const last = focusable[focusable.length - 1];

      if (e.shiftKey && document.activeElement === first) {
        e.preventDefault();
        last.focus();
      } else if (!e.shiftKey && document.activeElement === last) {
        e.preventDefault();
        first.focus();
      }
    };
  }
  window.SharlanA11y = { trapFocus: trapFocus };

  const nav = document.querySelector('.main-nav');
  const hamburger = document.querySelector('.hamburger');
  const mobileNavPanel = document.querySelector('.mobile-nav-panel');
  const mobileNavOverlay = document.querySelector('.mobile-nav-overlay');
  const mobileNavClose = document.querySelector('.mobile-nav-close');
  const searchTrigger = document.querySelector('[data-search-trigger]');
  const searchOverlay = document.querySelector('.search-overlay');
  const searchClose = document.querySelector('.search-close');
  const searchInput = document.querySelector('.search-overlay input');

  /* ---- Sticky nav background on scroll ---- */
  function handleScroll() {
    if (!nav) return;
    if (window.scrollY > 40) {
      nav.classList.add('is-scrolled');
    } else {
      nav.classList.remove('is-scrolled');
    }
  }
  window.addEventListener('scroll', handleScroll, { passive: true });
  handleScroll();

  /* ---- Mobile slide-out menu ---- */
  const mobileNavTrapHandler = trapFocus(mobileNavPanel);

  function openMobileNav() {
    mobileNavPanel.classList.add('is-open');
    mobileNavOverlay.classList.add('is-open');
    hamburger.classList.add('is-open');
    hamburger.setAttribute('aria-expanded', 'true');
    document.body.style.overflow = 'hidden';
    document.addEventListener('keydown', mobileNavTrapHandler);
    const firstLink = mobileNavPanel.querySelector('.mobile-nav-links a');
    if (firstLink) firstLink.focus();
  }

  function closeMobileNav() {
    mobileNavPanel.classList.remove('is-open');
    mobileNavOverlay.classList.remove('is-open');
    hamburger.classList.remove('is-open');
    hamburger.setAttribute('aria-expanded', 'false');
    document.body.style.overflow = '';
    document.removeEventListener('keydown', mobileNavTrapHandler);
    hamburger.focus();
  }

  if (hamburger) {
    hamburger.addEventListener('click', () => {
      const isOpen = mobileNavPanel.classList.contains('is-open');
      isOpen ? closeMobileNav() : openMobileNav();
    });
  }

  if (mobileNavClose) mobileNavClose.addEventListener('click', closeMobileNav);
  if (mobileNavOverlay) mobileNavOverlay.addEventListener('click', closeMobileNav);

  document.querySelectorAll('.mobile-nav-links a').forEach((link) => {
    link.addEventListener('click', closeMobileNav);
  });

  /* ---- Search overlay ---- */
  const searchTrapHandler = trapFocus(searchOverlay);

  function openSearch() {
    searchOverlay.classList.add('is-open');
    document.body.style.overflow = 'hidden';
    document.addEventListener('keydown', searchTrapHandler);
    setTimeout(() => searchInput && searchInput.focus(), 300);
  }

  function closeSearch() {
    searchOverlay.classList.remove('is-open');
    document.body.style.overflow = '';
    document.removeEventListener('keydown', searchTrapHandler);
    if (searchTrigger) searchTrigger.focus();
  }

  if (searchTrigger) searchTrigger.addEventListener('click', openSearch);
  if (searchClose) searchClose.addEventListener('click', closeSearch);
  if (searchOverlay) {
    searchOverlay.addEventListener('click', (e) => {
      if (e.target === searchOverlay) closeSearch();
    });
  }

  /* ---- Escape key closes any open overlay ---- */
  document.addEventListener('keydown', (e) => {
    if (e.key !== 'Escape') return;
    if (mobileNavPanel && mobileNavPanel.classList.contains('is-open')) closeMobileNav();
    if (searchOverlay && searchOverlay.classList.contains('is-open')) closeSearch();
  });

  /* ---- Close mobile panel automatically if resized to desktop ---- */
  window.addEventListener('resize', () => {
    if (window.innerWidth > 992 && mobileNavPanel.classList.contains('is-open')) {
      closeMobileNav();
    }
  });
})();
