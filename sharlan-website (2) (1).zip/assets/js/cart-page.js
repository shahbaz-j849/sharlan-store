/* ==========================================================================
   SHARLAN — CART-PAGE.JS  (Launch-Safe Version)
   Full Cart page (as opposed to the quick-access drawer from app.js).
   Reads/writes the same cart via window.SharlanCart.

   LAUNCH-SAFETY NOTE: this file previously included a fake coupon system
   and a fabricated per-city shipping cost/day estimator. Both are removed
   here because neither was backed by a real discount engine or a real
   courier agreement — showing them risked misleading a real customer.
   The "Proceed to Checkout" button has also been replaced with a WhatsApp
   order-request flow, since no payment gateway or order backend exists
   yet (Medusa is still being built separately). None of this generates
   a fake order number or writes a fake order anywhere — it only opens a
   pre-filled WhatsApp message built from the real cart contents, which a
   human on the SHARLAN team then reviews and confirms manually.
   ========================================================================== */

(function () {
  'use strict';

  const SHARLAN_WHATSAPP_NUMBER = '923162109008'; // +92 316 210 9008, no leading + for wa.me

  function formatPKR(amount) {
    return 'Rs. ' + Number(amount).toLocaleString('en-PK');
  }

  const listEl = document.getElementById('cart-page-list');
  const emptyEl = document.getElementById('cart-page-empty');
  const summaryWrap = document.getElementById('cart-page-summary-wrap');
  const summaryItemsEl = document.getElementById('order-summary-items');
  const subtotalEl = document.getElementById('summary-subtotal');
  const whatsappBtn = document.getElementById('cart-page-whatsapp-btn');

  function render() {
    const items = window.SharlanCart ? window.SharlanCart.getItems() : [];

    if (!items.length) {
      if (listEl) listEl.innerHTML = '';
      if (emptyEl) emptyEl.style.display = '';
      if (summaryWrap) summaryWrap.style.display = 'none';
      return;
    }

    if (emptyEl) emptyEl.style.display = 'none';
    if (summaryWrap) summaryWrap.style.display = '';

    if (listEl) {
      listEl.innerHTML = items
        .map(
          (item, i) =>
            '<div class="cart-page-item" data-index="' + i + '">' +
            '<img src="' + item.image + '" alt="' + item.name + '">' +
            '<div class="cart-page-item-info">' +
            '<h3>' + item.name + '</h3>' +
            '<div class="meta">' + (item.size ? 'Size: ' + item.size : 'One size') + '</div>' +
            '<div class="qty-control" style="margin-top:12px;">' +
            '<button type="button" data-qty-decrease aria-label="Decrease quantity">-</button>' +
            '<span>' + item.qty + '</span>' +
            '<button type="button" data-qty-increase aria-label="Increase quantity">+</button>' +
            '</div>' +
            '</div>' +
            '<div class="cart-page-item-price">' + formatPKR(item.price * item.qty) + '</div>' +
            '<button type="button" class="cart-page-item-remove" data-remove aria-label="Remove item"><i class="fa-solid fa-trash"></i></button>' +
            '</div>'
        )
        .join('');
    }

    renderSummary(items);
  }

  function renderSummary(items) {
    const subtotal = items.reduce((sum, item) => sum + item.price * item.qty, 0);

    if (summaryItemsEl) {
      summaryItemsEl.innerHTML = items
        .map(
          (item) =>
            '<div class="order-summary-item">' +
            '<img src="' + item.image + '" alt="' + item.name + '">' +
            '<div class="order-summary-item-info"><h4>' + item.name + '</h4><span>' + (item.size ? 'Size ' + item.size : '') + ' × ' + item.qty + '</span></div>' +
            '<div class="order-summary-item-price">' + formatPKR(item.price * item.qty) + '</div>' +
            '</div>'
        )
        .join('');
    }

    if (subtotalEl) subtotalEl.textContent = formatPKR(subtotal);
  }

  /* ---- Quantity / remove (delegated) ---- */
  if (listEl) {
    listEl.addEventListener('click', (e) => {
      if (!window.SharlanCart) return;
      const card = e.target.closest('[data-index]');
      if (!card) return;
      const index = Number(card.dataset.index);

      if (e.target.closest('[data-qty-increase]')) {
        window.SharlanCart.increaseAt(index);
      } else if (e.target.closest('[data-qty-decrease]')) {
        window.SharlanCart.decreaseAt(index);
      } else if (e.target.closest('[data-remove]')) {
        window.SharlanCart.removeAt(index);
      } else {
        return;
      }
      render();
    });
  }

  /* --------------------------------------------------------------------
     SEND ORDER REQUEST VIA WHATSAPP
     Builds a plain-text order summary from the real, current cart and
     opens it as a pre-filled WhatsApp message to the real SHARLAN number.
     This does NOT create an order, does NOT generate an order number, and
     does NOT save anything anywhere — SHARLAN staff confirm manually.
     -------------------------------------------------------------------- */
  function buildWhatsAppMessage(items) {
    const subtotal = items.reduce((sum, item) => sum + item.price * item.qty, 0);

    const lines = [];
    lines.push('Hi SHARLAN! I\'d like to request an order:');
    lines.push('');

    items.forEach((item, i) => {
      let line = (i + 1) + '. ' + item.name;
      const details = [];
      if (item.size) details.push('Size: ' + item.size);
      if (item.color) details.push('Color: ' + item.color);
      details.push('Qty: ' + item.qty);
      line += ' (' + details.join(', ') + ') — ' + formatPKR(item.price * item.qty);
      lines.push(line);
    });

    lines.push('');
    lines.push('Subtotal: ' + formatPKR(subtotal));
    lines.push('');
    lines.push('Please confirm availability, delivery cost, and delivery time for my order.');

    return lines.join('\n');
  }

  if (whatsappBtn) {
    whatsappBtn.addEventListener('click', () => {
      const items = window.SharlanCart ? window.SharlanCart.getItems() : [];
      if (!items.length) return;

      const message = buildWhatsAppMessage(items);
      const encodedMessage = encodeURIComponent(message);
      const whatsappUrl = 'https://wa.me/' + SHARLAN_WHATSAPP_NUMBER + '?text=' + encodedMessage;

      window.open(whatsappUrl, '_blank', 'noopener');
    });
  }

  render();
})();
