/* ==========================================================================
   SHARLAN — TRACK-ORDER.JS
   Looks up an order by number + contact (email or phone), matched against
   the shared orders-store. Renders a demo status timeline. No real
   courier integration yet — statuses come from orders-store.js.
   ========================================================================== */

(function () {
  'use strict';

  if (window.SharlanOrders && window.SharlanOrders.seedDemoIfEmpty) {
    window.SharlanOrders.seedDemoIfEmpty();
  }

  const STAGES = ['processing', 'shipped', 'delivered'];
  const STAGE_LABELS = {
    processing: { title: 'Order Confirmed', desc: 'We\'ve received your order and are preparing it for shipment.', icon: 'fa-receipt' },
    shipped: { title: 'Shipped', desc: 'Your order is on its way with our courier partner.', icon: 'fa-truck-fast' },
    delivered: { title: 'Delivered', desc: 'Your order has been delivered. Enjoy!', icon: 'fa-box-open' }
  };

  const form = document.getElementById('track-order-form');
  const resultWrap = document.getElementById('track-result');
  const notFoundWrap = document.getElementById('track-not-found');

  function formatPKR(amount) {
    return 'Rs. ' + Number(amount).toLocaleString('en-PK');
  }

  function formatDate(iso) {
    return new Date(iso).toLocaleDateString('en-PK', { day: 'numeric', month: 'short', year: 'numeric' });
  }

  function renderTimeline(status) {
    const currentIndex = STAGES.indexOf(status);
    return STAGES.map((stage, i) => {
      const info = STAGE_LABELS[stage];
      const state = i < currentIndex ? 'complete' : i === currentIndex ? 'active' : 'pending';
      return (
        '<div class="timeline-step timeline-' + state + '">' +
        '<div class="timeline-icon"><i class="fa-solid ' + info.icon + '"></i></div>' +
        '<div class="timeline-body"><strong>' + info.title + '</strong><p>' + info.desc + '</p></div>' +
        '</div>'
      );
    }).join('<div class="timeline-connector"></div>');
  }

  function renderOrder(order) {
    notFoundWrap.style.display = 'none';
    resultWrap.style.display = '';

    document.getElementById('track-order-id').textContent = order.id;
    document.getElementById('track-order-date').textContent = formatDate(order.date);
    document.getElementById('track-order-total').textContent = formatPKR(order.total);
    document.getElementById('track-order-address').textContent = order.shippingAddress.address + ', ' + order.shippingAddress.city;
    document.getElementById('track-timeline').innerHTML = renderTimeline(order.status);

    document.getElementById('track-order-items').innerHTML = order.items
      .map(
        (item) =>
          '<div class="order-summary-item">' +
          '<img src="' + item.image + '" alt="' + item.name + '">' +
          '<div class="order-summary-item-info"><h4>' + item.name + '</h4><span>' + (item.size ? 'Size ' + item.size : '') + ' × ' + item.qty + '</span></div>' +
          '<div class="order-summary-item-price">' + formatPKR(item.price * item.qty) + '</div>' +
          '</div>'
      )
      .join('');
  }

  form.addEventListener('submit', (e) => {
    e.preventDefault();
    const orderNumber = document.getElementById('track-order-number').value.trim();
    const contact = document.getElementById('track-contact').value.trim().toLowerCase();

    const order = window.SharlanOrders ? window.SharlanOrders.getById(orderNumber) : null;

    const contactMatches =
      order &&
      ((order.billing.email || '').toLowerCase() === contact || (order.billing.phone || '').replace(/\s/g, '') === contact.replace(/\s/g, ''));

    if (!order || !contactMatches) {
      resultWrap.style.display = 'none';
      notFoundWrap.style.display = '';
      return;
    }

    renderOrder(order);
  });

  /* Convenience: prefill with a demo order number so reviewers can see
     the timeline without needing to place a real order first. */
  const demoHint = document.getElementById('track-demo-hint');
  if (demoHint) {
    const orders = window.SharlanOrders ? window.SharlanOrders.getAll() : [];
    if (orders[0]) {
      demoHint.innerHTML = 'Try order <strong>' + orders[0].id + '</strong> with contact <strong>' + orders[0].billing.email + '</strong>';
    }
  }
})();
