/* ==========================================================================
   SHARLAN — APP.JS
   Application state: cart drawer (add/remove/quantity), PKR currency
   formatting. Checkout logic itself is intentionally out of scope for
   Phase 1 — this only prepares the cart UI and data shape.
   ========================================================================== */

(function () {
  'use strict';

  /* --------------------------------------------------------------------
     CURRENCY — PKR formatting helper, used across the homepage
     -------------------------------------------------------------------- */
  function formatPKR(amount) {
    return 'Rs. ' + Number(amount).toLocaleString('en-PK');
  }
  window.formatPKR = formatPKR;

  /* --------------------------------------------------------------------
     CART STATE
     Shape: [{ id, name, price, image, size, qty }]
     Persisted to localStorage so the count survives a page reload.
     -------------------------------------------------------------------- */
  const STORAGE_KEY = 'sharlan_cart_v1';
  let cart = loadCart();

  function loadCart() {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      return raw ? JSON.parse(raw) : [];
    } catch (err) {
      return [];
    }
  }

  function saveCart() {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(cart));
    } catch (err) {
      /* localStorage unavailable — cart still works for this session */
    }
  }

  const cartCountEl = document.getElementById('cart-count');
  const cartDrawer = document.querySelector('.cart-drawer');
  const cartOverlay = document.querySelector('.cart-overlay');
  const cartBody = document.querySelector('.cart-drawer-body');
  const cartSubtotalEl = document.querySelector('[data-cart-subtotal]');
  const cartTrigger = document.querySelector('[data-cart-trigger]');
  const cartClose = document.querySelector('.cart-drawer-close');

  function cartTotalQty() {
    return cart.reduce((sum, item) => sum + item.qty, 0);
  }

  function cartSubtotal() {
    return cart.reduce((sum, item) => sum + item.price * item.qty, 0);
  }

  function renderCartBadge() {
    if (!cartCountEl) return;
    const qty = cartTotalQty();
    cartCountEl.textContent = qty;
    cartCountEl.classList.toggle('is-visible', qty > 0);
  }

  function renderCartDrawer() {
    if (!cartBody) return;

    if (cart.length === 0) {
      cartBody.innerHTML =
        '<div class="cart-empty-state">' +
        '<i class="fa-solid fa-bag-shopping"></i>' +
        '<p>Your bag is empty.</p>' +
        '<p style="font-size:0.8rem;">Start adding pieces from the winter collection.</p>' +
        '</div>';
    } else {
      cartBody.innerHTML = cart
        .map(
          (item, index) =>
            '<div class="cart-line-item" data-index="' + index + '">' +
            '<img src="' + item.image + '" alt="' + item.name + '">' +
            '<div class="cart-line-info">' +
            '<h4>' + item.name + '</h4>' +
            '<div class="cart-line-meta">' + (item.size ? 'Size: ' + item.size : '') + '</div>' +
            '<div class="qty-control">' +
            '<button type="button" data-qty-decrease aria-label="Decrease quantity">-</button>' +
            '<span>' + item.qty + '</span>' +
            '<button type="button" data-qty-increase aria-label="Increase quantity">+</button>' +
            '</div>' +
            '<div><button type="button" class="cart-line-remove" data-cart-remove>Remove</button></div>' +
            '</div>' +
            '<div style="font-weight:700;">' + formatPKR(item.price * item.qty) + '</div>' +
            '</div>'
        )
        .join('');
    }

    if (cartSubtotalEl) cartSubtotalEl.textContent = formatPKR(cartSubtotal());
  }

  const cartTrapHandler = window.SharlanA11y ? window.SharlanA11y.trapFocus(cartDrawer) : null;

  function openCart() {
    cartDrawer.classList.add('is-open');
    cartOverlay.classList.add('is-open');
    document.body.style.overflow = 'hidden';
    if (cartTrapHandler) document.addEventListener('keydown', cartTrapHandler);
    if (cartClose) cartClose.focus();
  }

  function closeCart() {
    cartDrawer.classList.remove('is-open');
    cartOverlay.classList.remove('is-open');
    document.body.style.overflow = '';
    if (cartTrapHandler) document.removeEventListener('keydown', cartTrapHandler);
    if (cartTrigger) cartTrigger.focus();
  }

  if (cartTrigger) cartTrigger.addEventListener('click', openCart);
  if (cartClose) cartClose.addEventListener('click', closeCart);
  if (cartOverlay) cartOverlay.addEventListener('click', closeCart);

  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && cartDrawer && cartDrawer.classList.contains('is-open')) {
      closeCart();
    }
  });

  function addToCart(product) {
    const existing = cart.find((item) => item.id === product.id && item.size === product.size);
    if (existing) {
      existing.qty += 1;
    } else {
      cart.push(Object.assign({ qty: 1 }, product));
    }
    saveCart();
    renderCartBadge();
    renderCartDrawer();
  }

  if (cartBody) {
    cartBody.addEventListener('click', (e) => {
      const line = e.target.closest('.cart-line-item');
      if (!line) return;
      const index = Number(line.dataset.index);

      if (e.target.matches('[data-qty-increase]')) {
        cart[index].qty += 1;
      } else if (e.target.matches('[data-qty-decrease]')) {
        cart[index].qty -= 1;
        if (cart[index].qty <= 0) cart.splice(index, 1);
      } else if (e.target.matches('[data-cart-remove]')) {
        cart.splice(index, 1);
      } else {
        return;
      }

      saveCart();
      renderCartBadge();
      renderCartDrawer();
    });
  }

  /* ---- Wire up every "Add to Cart" button on the homepage ---- */
  document.querySelectorAll('.add-to-cart').forEach((btn) => {
    btn.addEventListener('click', () => {
      const card = btn.closest('[data-product-id]');
      if (!card) return;

      const product = {
        id: card.dataset.productId,
        name: card.dataset.productName,
        price: Number(card.dataset.productPrice),
        image: card.dataset.productImage,
        size: null,
      };

      addToCart(product);

      const originalLabel = btn.querySelector('span').textContent;
      btn.querySelector('span').textContent = 'Added';
      btn.classList.add('is-added');
      setTimeout(() => {
        btn.querySelector('span').textContent = originalLabel;
        btn.classList.remove('is-added');
      }, 1200);

      if (window.SharlanToast) {
        window.SharlanToast.show(product.name + ' added to your bag', 'success');
      }
    });
  });

  function removeAt(index) {
    if (!cart[index]) return;
    cart.splice(index, 1);
    saveCart();
    renderCartBadge();
    renderCartDrawer();
  }

  function decreaseAt(index) {
    if (!cart[index]) return;
    cart[index].qty -= 1;
    if (cart[index].qty <= 0) cart.splice(index, 1);
    saveCart();
    renderCartBadge();
    renderCartDrawer();
  }

  function increaseAt(index) {
    if (!cart[index]) return;
    cart[index].qty += 1;
    saveCart();
    renderCartBadge();
    renderCartDrawer();
  }

  function clearCart() {
    cart = [];
    saveCart();
    renderCartBadge();
    renderCartDrawer();
  }

  /* --------------------------------------------------------------------
     PUBLIC CART API
     Exposed so shop.js, product-detail.js, wishlist.js, and cart-page.js
     can read/mutate the cart without duplicating this logic per page.
     -------------------------------------------------------------------- */
  window.SharlanCart = {
    add: addToCart,
    removeAt: removeAt,
    decreaseAt: decreaseAt,
    increaseAt: increaseAt,
    clear: clearCart,
    getItems: () => cart.slice(),
    getCount: cartTotalQty,
    getSubtotal: cartSubtotal
  };

  /* ---- Initial render on page load ---- */
  renderCartBadge();
  renderCartDrawer();
})();
